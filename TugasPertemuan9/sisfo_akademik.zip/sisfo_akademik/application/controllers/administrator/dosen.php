<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dosen extends CI_Controller {

    public function __construct()
    {
        parent::__construct();

        if (!isset($this->session->userdata['username'])) {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">Anda Belum Login!<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
            redirect('administrator/auth');
        }
    }

    public function index()
    {
        $data['dosen'] = $this->dosen_model->tampil_data('dosen')->result();
        $this->load->view('templates_administrator/header');
        $this->load->view('templates_administrator/sidebar');
        $this->load->view('administrator/dosen', $data);
        $this->load->view('templates_administrator/footer');
    }

    public function detail($id)
    {
        $data['detail'] = $this->dosen_model->ambil_id_dosen($id);
        $this->load->view('templates_administrator/header');
        $this->load->view('templates_administrator/sidebar');
        $this->load->view('administrator/dosen_detail', $data);
        $this->load->view('templates_administrator/footer');
    }

    public function tambah_dosen()
    {
        $this->load->view('templates_administrator/header');
        $this->load->view('templates_administrator/sidebar');
        $this->load->view('administrator/dosen_form');
        $this->load->view('templates_administrator/footer');
    }

    public function tambah_dosen_aksi()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->tambah_dosen();
            return;
        }

        $data = array(
            'nidn'          => $this->input->post('nidn', TRUE),
            'nama_dosen'    => $this->input->post('nama_dosen', TRUE),
            'alamat'        => $this->input->post('alamat', TRUE),
            'jenis_kelamin' => $this->input->post('jenis_kelamin', TRUE),
            'email'         => $this->input->post('email', TRUE),
            'telp'          => $this->input->post('telp', TRUE),
            'photo'         => $this->_uploadPhoto('photo', 'default.jpg')
        );

        $this->dosen_model->insert_data($data, 'dosen');
        $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">Data Dosen Berhasil Ditambahkan!<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
        redirect('administrator/dosen');
    }

    public function update($id)
    {
        $data['dosen'] = $this->dosen_model->ambil_id_dosen($id);
        if (!$data['dosen']) {
            redirect('administrator/dosen');
        }

        $this->load->view('templates_administrator/header');
        $this->load->view('templates_administrator/sidebar');
        $this->load->view('administrator/dosen_update', $data);
        $this->load->view('templates_administrator/footer');
    }

    public function update_dosen_aksi()
    {
        $this->_rules();

        $id = $this->input->post('id_dosen', TRUE);
        if ($this->form_validation->run() == FALSE) {
            $this->update($id);
            return;
        }

        $data = array(
            'nidn'          => $this->input->post('nidn', TRUE),
            'nama_dosen'    => $this->input->post('nama_dosen', TRUE),
            'alamat'        => $this->input->post('alamat', TRUE),
            'jenis_kelamin' => $this->input->post('jenis_kelamin', TRUE),
            'email'         => $this->input->post('email', TRUE),
            'telp'          => $this->input->post('telp', TRUE)
        );

        $uploaded = $this->_uploadPhoto('photo', NULL);
        if ($uploaded !== NULL) {
            $data['photo'] = $uploaded;
        }

        $where = array('id_dosen' => $id);
        $this->dosen_model->update_data($where, $data, 'dosen');
        $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">Data Dosen Berhasil Diupdate!<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
        redirect('administrator/dosen');
    }

    public function delete($id)
    {
        $where = array('id_dosen' => $id);
        $this->dosen_model->hapus_data($where, 'dosen');
        $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">Data Dosen Berhasil Dihapus!<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
        redirect('administrator/dosen');
    }

    private function _uploadPhoto($field, $fallback = 'default.jpg')
    {
        if (empty($_FILES[$field]['name'])) {
            return $fallback;
        }

        $config = array(
            'upload_path'   => './assets/uploads',
            'allowed_types' => 'jpg|png|gif|jpeg'
        );

        $this->upload->initialize($config);
        if ($this->upload->do_upload($field)) {
            return $this->upload->data('file_name');
        }

        return $fallback;
    }

    public function _rules()
    {
        $this->form_validation->set_rules('nidn', 'NIDN', 'required', array('required' => '%s wajib diisi!'));
        $this->form_validation->set_rules('nama_dosen', 'Nama Dosen', 'required', array('required' => '%s wajib diisi!'));
        $this->form_validation->set_rules('alamat', 'Alamat', 'required', array('required' => '%s wajib diisi!'));
        $this->form_validation->set_rules('jenis_kelamin', 'Jenis Kelamin', 'required', array('required' => '%s wajib diisi!'));
        $this->form_validation->set_rules('email', 'Email', 'required', array('required' => '%s wajib diisi!'));
        $this->form_validation->set_rules('telp', 'Nomor Telepon', 'required', array('required' => '%s wajib diisi!'));
    }
}
