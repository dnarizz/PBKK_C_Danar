<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hubungi_kami extends CI_Controller {

    public function index()
    {
        $data['hubungi'] = $this->hubungi_model->tampil_data('hubungi')->result();
        $this->load->view('templates_administrator/header');
        $this->load->view('templates_administrator/sidebar');
        $this->load->view('administrator/hubungi_kami', $data);
        $this->load->view('templates_administrator/footer');
    }

    public function kirim_email($id)
    {
        $where = array('id_hubungi' => $id);
        $data['hubungi'] = $this->hubungi_model->kirim_data($where, 'hubungi')->result();
        $this->load->view('templates_administrator/header');
        $this->load->view('templates_administrator/sidebar');
        $this->load->view('administrator/form_kirim_email', $data);
        $this->load->view('templates_administrator/footer');
    }

    public function kirim_email_aksi()
    {
        $to_email = $this->input->post('email');
        $subject  = $this->input->post('subject');
        $message  = $this->input->post('pesan');

        $config = array(
            'protocol'  => 'smtp',
            'smtp_host' => 'ssl://smtp.googlemail.com',
            'smtp_port' => 465,
            'smtp_user' => 'admin@kampus.ac.id',
            'smtp_pass' => 'password',
            'mailtype'  => 'html',
            'charset'   => 'utf-8',
            'newline'   => "\r\n"
        );

        $this->load->library('email', $config);
        $this->email->from("Universitas Teknologi Nusantara");
        $this->email->to($to_email);
        $this->email->subject($subject);
        $this->email->message($message);

        if ($this->email->send()) {
            $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">Pesan Terkirim!<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
            redirect('administrator/hubungi_kami');
        } else {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">Pesan Gagal Dikirim (Konfigurasi SMTP Lokal)!<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
            redirect('administrator/hubungi_kami');
        }
    }

    public function delete($id)
    {
        $where = array('id_hubungi' => $id);
        $this->hubungi_model->hapus_data($where, 'hubungi');
        $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">Data Pesan Berhasil Dihapus!<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
        redirect('administrator/hubungi_kami');
    }
}
