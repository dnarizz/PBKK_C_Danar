<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dosen_model extends CI_Model {

    public $table = 'dosen';
    public $id = 'id_dosen';

    public function tampil_data($table = 'dosen')
    {
        return $this->db->get($table);
    }

    public function ambil_id_dosen($id)
    {
        $hasil = $this->db->where('id_dosen', $id)->get($this->table);
        if ($hasil->num_rows() > 0) {
            return $hasil->result();
        } else {
            return false;
        }
    }

    public function insert_data($data, $table = 'dosen')
    {
        $this->db->insert($table, $data);
    }

    public function update_data($where, $data, $table = 'dosen')
    {
        $this->db->where($where);
        $this->db->update($table, $data);
    }

    public function hapus_data($where, $table = 'dosen')
    {
        $this->db->where($where);
        $this->db->delete($table);
    }

    public function get_by_id($id)
    {
        $this->db->where($this->id, $id);
        return $this->db->get($this->table)->row();
    }
}
