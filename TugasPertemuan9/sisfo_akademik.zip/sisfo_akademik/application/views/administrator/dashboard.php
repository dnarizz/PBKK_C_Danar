<div class="container-fluid">
  <div class="alert alert-success" role="alert">
    <i class="fas fa-tachometer-alt"></i> Dashboard
  </div>

  <div class="alert alert-success" role="alert">
    <h4 class="alert-heading">Selamat Datang!</h4>
    <p>Selamat Datang <strong><?php echo $username; ?></strong> di Sistem Informasi Akademik Universitas Teknologi Nusantara, Anda Login sebagai <strong><?php echo $level; ?></strong></p>
    <hr>
    <button type="button" class="btn btn-sm btn-info" data-toggle="modal" data-target="#exampleModal">
      <i class="fas fa-cogs"></i> Control Panel
    </button>
  </div>

  <!-- Button trigger modal -->
  <!-- Modal -->
  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"><i class="fas fa-cogs"></i> Control Panel</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-md-3 text-info text-center">
              <a href="<?php echo base_url('administrator/mahasiswa') ?>">
                <p class="nav-link small text-info">MAHASISWA</p>
              </a>
              <i class="fas fa-3x fa-user-graduate"></i>
            </div>

            <div class="col-md-3 text-info text-center">
              <a href="<?php echo base_url('administrator/tahun_akademik') ?>">
                <p class="nav-link small text-info">TAHUN AKADEMIK</p>
              </a>
              <i class="fas fa-3x fa-calendar-alt"></i>
            </div>

            <div class="col-md-3 text-info text-center">
              <a href="<?php echo base_url('administrator/krs') ?>">
                <p class="nav-link small text-info">KRS</p>
              </a>
              <i class="fas fa-3x fa-edit"></i>
            </div>

            <div class="col-md-3 text-info text-center">
              <a href="<?php echo base_url('administrator/nilai') ?>">
                <p class="nav-link small text-info">KHS</p>
              </a>
              <i class="fas fa-3x fa-file-alt"></i>
            </div>
          </div><hr>

          <div class="row">
            <div class="col-md-3 text-info text-center">
              <a href="<?php echo base_url('administrator/nilai/input_nilai') ?>">
                <p class="nav-link small text-info">INPUT NILAI</p>
              </a>
              <i class="fas fa-3x fa-sort-numeric-down"></i>
            </div>

            <div class="col-md-3 text-info text-center">
              <a href="<?php echo base_url('administrator/transkrip_nilai') ?>">
                <p class="nav-link small text-info">CETAK TRANSKRIP</p>
              </a>
              <i class="fas fa-3x fa-print"></i>
            </div>

            <div class="col-md-3 text-info text-center">
              <a href="<?php echo base_url('administrator/informasi') ?>">
                <p class="nav-link small text-info">INFO KAMPUS</p>
              </a>
              <i class="fas fa-3x fa-bullhorn"></i>
            </div>

            <div class="col-md-3 text-info text-center">
              <a href="<?php echo base_url('administrator/identitas') ?>">
                <p class="nav-link small text-info">IDENTITAS</p>
              </a>
              <i class="fas fa-3x fa-id-card-alt"></i>
            </div>
          </div><hr>

          <div class="row">
            <div class="col-md-3 text-info text-center">
              <a href="<?php echo base_url('administrator/tentang_kampus') ?>">
                <p class="nav-link small text-info">TENTANG KAMPUS</p>
              </a>
              <i class="fas fa-3x fa-info-circle"></i>
            </div>

            <div class="col-md-3 text-info text-center">
              <a href="<?php echo base_url('administrator/jurusan') ?>">
                <p class="nav-link small text-info">JURUSAN</p>
              </a>
              <i class="fas fa-3x fa-university"></i>
            </div>

            <div class="col-md-3 text-info text-center">
              <a href="<?php echo base_url('administrator/prodi') ?>">
                <p class="nav-link small text-info">PROGRAM STUDI</p>
              </a>
              <i class="fas fa-3x fa-graduation-cap"></i>
            </div>

            <div class="col-md-3 text-info text-center">
              <a href="<?php echo base_url('administrator/user') ?>">
                <p class="nav-link small text-info">USER</p>
              </a>
              <i class="fas fa-3x fa-users"></i>
            </div>
          </div><hr>

          <div class="row">
            <div class="col-md-3 text-info text-center">
              <a href="<?php echo base_url('administrator/dosen') ?>">
                <p class="nav-link small text-info">DOSEN</p>
              </a>
              <i class="fas fa-3x fa-chalkboard-teacher"></i>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
</div>
