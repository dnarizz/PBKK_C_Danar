<div class="container-fluid">
  <center>
    <legend><strong>TRANSKRIP NILAI</strong></legend>

    <table>
      <tr>
        <td>NIM</td>
        <td>: <?php echo $nim; ?></td>
      </tr>
      <tr>
        <td>Nama</td>
        <td>: <?php echo $nama; ?></td>
      </tr>
      <tr>
        <td>Program Studi</td>
        <td>: <?php echo $prodi; ?></td>
      </tr>
    </table>
  </center>

  <table class="table table-bordered table-hover table-striped mt-3">
    <tr>
      <th>NO</th>
      <th>KODE MATA KULIAH</th>
      <th>NAMA MATA KULIAH</th>
      <th align="center">SKS</th>
      <th align="center">NILAI</th>
      <th align="center">SKOR</th>
    </tr>

    <?php
    $no = 1;
    $JmlSks = 0;
    $JmlSkor = 0;

    foreach ($transkrip as $tr) : ?>
      <tr>
        <td><?php echo $no++ ?></td>
        <td><?php echo $tr->kode_matakuliah; ?></td>
        <td><?php echo $tr->nama_matakuliah; ?></td>
        <td align="center"><?php echo $tr->sks; ?></td>
        <td align="center"><?php echo $tr->nilai; ?></td>
        <td align="center"><?php echo skorNilai($tr->nilai, $tr->sks); ?></td>
        <?php
        $JmlSks += $tr->sks;
        $JmlSkor += skorNilai($tr->nilai, $tr->sks);
        ?>
      </tr>
    <?php endforeach; ?>
    <tr>
      <td colspan="3">Jumlah</td>
      <td align="center"><?php echo $JmlSks ?></td>
      <td></td>
      <td align="center"><?php echo $JmlSkor ?></td>
    </tr>
  </table>

  <p class="text-center">Index Prestasi Kumulatif : <?php echo ($JmlSks > 0) ? number_format($JmlSkor / $JmlSks, 2) : '0.00'; ?></p>
  <?php echo anchor('administrator/transkrip_nilai', '<div class="btn btn-sm btn-secondary">Kembali</div>') ?>
</div>
