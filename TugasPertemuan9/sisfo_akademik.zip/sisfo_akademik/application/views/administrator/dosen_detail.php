<div class="container-fluid">
  <div class="alert alert-success" role="alert">
    <i class="fa fa-eye"></i> Detail Dosen
  </div>

  <?php if (!empty($detail)) : ?>
    <?php foreach ($detail as $dt) : ?>
      <img class="mb-4" src="<?php echo base_url('assets/uploads/') . $dt->photo ?>" style="width: 20%" onerror="this.src='<?php echo base_url('assets/img/undraw_profile.svg') ?>'">

      <table class="table table-hover table-bordered table-striped">
        <tr>
          <td>NIDN</td>
          <td><?php echo html_escape($dt->nidn); ?></td>
        </tr>
        <tr>
          <td>NAMA DOSEN</td>
          <td><?php echo html_escape($dt->nama_dosen); ?></td>
        </tr>
        <tr>
          <td>ALAMAT</td>
          <td><?php echo html_escape($dt->alamat); ?></td>
        </tr>
        <tr>
          <td>JENIS KELAMIN</td>
          <td><?php echo html_escape($dt->jenis_kelamin); ?></td>
        </tr>
        <tr>
          <td>EMAIL</td>
          <td><?php echo html_escape($dt->email); ?></td>
        </tr>
        <tr>
          <td>NO. TELEPON</td>
          <td><?php echo html_escape($dt->telp); ?></td>
        </tr>
      </table>
    <?php endforeach; ?>
  <?php else : ?>
    <div class="alert alert-warning">Data dosen tidak ditemukan.</div>
  <?php endif; ?>

  <?php echo anchor('administrator/dosen', '<div class="btn btn-sm btn-primary">Kembali</div>') ?><br><br><br><br>
</div>
