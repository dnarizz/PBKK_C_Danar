<div class="container-fluid">
  <div class="alert alert-success">
    <i class="fas fa-university"></i> Form Masuk Halaman Transkrip Nilai
  </div>

  <?php echo $this->session->flashdata('pesan') ?>

  <form method="post" action="<?php echo base_url('administrator/transkrip_nilai/buat_transkrip_aksi') ?>">
    <div class="form-group">
      <label>NIM</label>
      <input type="text" name="nim" class="form-control" placeholder="Masukkan NIM Mahasiswa (Contoh: 1219001)">
      <?php echo form_error('nim', '<div class="text-danger small ml-2">', '</div>') ?>
    </div>

    <button type="submit" class="btn btn-primary">Proses</button>
  </form>
</div>
