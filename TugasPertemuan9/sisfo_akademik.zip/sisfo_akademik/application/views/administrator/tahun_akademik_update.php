<div class="container-fluid">
  <div class="alert alert-success" role="alert">
    <i class="fas fa-edit"></i> Form Update Tahun Akademik
  </div>

  <?php foreach ($tahun_akademik as $ta) : ?>
    <form method="post" action="<?php echo base_url('administrator/tahun_akademik/update_aksi') ?>">
      <div class="form-group">
        <label>Tahun Akademik</label>
        <input type="hidden" name="id_thn_akad" class="form-control" value="<?php echo $ta->id_thn_akad ?>">
        <input type="text" name="tahun_akademik" class="form-control" value="<?php echo $ta->tahun_akademik ?>">
      </div>

      <div class="form-group">
        <label>Semester</label>
        <select name="semester" class="form-control">
          <option><?php echo $ta->semester ?></option>
          <option>Ganjil</option>
          <option>Genap</option>
        </select>
      </div>

      <div class="form-group">
        <label>Status</label>
        <select name="status" class="form-control">
          <option><?php echo $ta->status ?></option>
          <option>Aktif</option>
          <option>Tidak Aktif</option>
        </select>
      </div>

      <button type="submit" class="btn btn-primary">Simpan</button>
      <?php echo anchor('administrator/tahun_akademik', '<div class="btn btn-secondary">Kembali</div>') ?>
    </form>
  <?php endforeach; ?>
</div>
