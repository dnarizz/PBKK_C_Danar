<div class="container-fluid">
  <div class="alert alert-success" role="alert">
    <i class="fas fa-university"></i> Form Update Tentang Kampus
  </div>

  <?php foreach ($tentang as $ttg) : ?>
    <form method="post" action="<?php echo base_url('administrator/tentang_kampus/update_aksi') ?>">
      <div class="form-group">
        <label>Sejarah</label>
        <input type="hidden" name="id" value="<?php echo $ttg->id ?>">
        <textarea name="sejarah" class="form-control" rows="4"><?php echo $ttg->sejarah ?></textarea>
      </div>

      <div class="form-group">
        <label>Visi</label>
        <textarea name="visi" class="form-control" rows="3"><?php echo $ttg->visi ?></textarea>
      </div>

      <div class="form-group">
        <label>Misi</label>
        <textarea name="misi" class="form-control" rows="4"><?php echo $ttg->misi ?></textarea>
      </div>

      <button type="submit" class="btn btn-primary">Simpan</button>
      <?php echo anchor('administrator/tentang_kampus', '<div class="btn btn-secondary">Kembali</div>') ?>
    </form>
  <?php endforeach; ?>
</div>
