<nav class="navbar navbar-light bg-warning text-dark">
  <?php foreach ($identitas as $id) : ?>
    <a class="navbar-brand"><strong><?php echo $id->judul_website ?></strong></a>
    <span class="small"><?php echo $id->alamat ?> - <?php echo $id->email ?> - <?php echo $id->telp ?></span>
  <?php endforeach; ?>
  <form class="form-inline">
    <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    <a class="btn btn-outline-primary my-2 my-sm-0 ml-2" href="<?php echo base_url('administrator/auth') ?>">Login</a>
  </form>
</nav>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav mx-auto">
      <a class="nav-item nav-link ml-3" href="#beranda">BERANDA <span class="sr-only">(current)</span></a>
      <a class="nav-item nav-link ml-3" href="#tentang">TENTANG KAMPUS</a>
      <a class="nav-item nav-link ml-3" href="#informasi">INFORMASI</a>
      <a class="nav-item nav-link ml-3" href="#kontak">KONTAK</a>
    </div>
  </div>
</nav>

<div id="beranda" class="jumbotron jumbotron-fluid bg-gradient-primary text-white text-center mb-4">
  <div class="container">
    <i class="fas fa-university fa-4x mb-3"></i>
    <?php foreach ($identitas as $id) : ?>
      <h1 class="display-4 font-weight-bold"><?php echo $id->judul_website ?></h1>
      <p class="lead"><?php echo $id->alamat ?> | Email: <?php echo $id->email ?> | Telp: <?php echo $id->telp ?></p>
    <?php endforeach; ?>
    <a href="<?php echo base_url('administrator/auth') ?>" class="btn btn-warning btn-lg font-weight-bold text-dark mt-2">
      <i class="fas fa-sign-in-alt mr-1"></i> Login Administrator SIAKAD
    </a>
  </div>
</div>

<!-- Card Tentang Kampus -->
<div id="tentang" class="card text-center m-5 shadow-sm">
  <div class="card-header bg-primary text-white">
    <strong>TENTANG KAMPUS</strong>
  </div>
  <div class="card-body">
    <p class="card-text">
      <?php foreach ($tentang as $ttg) : ?>
        <?php echo word_limiter($ttg->sejarah, 75) ?>
      <?php endforeach; ?>
    </p>
    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
      Selengkapnya...
    </button>
  </div>
</div>

<!-- Modal Tentang Kampus -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tentang Kampus</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body text-justify">
        <strong>SEJARAH UNIVERSITAS</strong>
        <?php foreach ($tentang as $ttg) : ?>
          <p><?php echo $ttg->sejarah ?></p>
        <?php endforeach; ?><br>

        <strong>VISI UNIVERSITAS</strong>
        <?php foreach ($tentang as $ttg) : ?>
          <p><?php echo $ttg->visi ?></p>
        <?php endforeach; ?><br>

        <strong>MISI UNIVERSITAS</strong>
        <?php foreach ($tentang as $ttg) : ?>
          <p><?php echo $ttg->misi ?></p>
        <?php endforeach; ?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Informasi Kampus -->
<div id="informasi" class="row m-4 text-center">
  <?php foreach ($informasi as $info) : ?>
    <div class="card m-3 shadow-sm" style="width: 18rem;">
      <span class="display-2 text-center text-info mt-3"><i class="<?php echo $info->icon ?>"></i></span>
      <div class="card-body">
        <h5 class="card-title badge badge-info"><?php echo $info->judul_informasi ?></h5>
        <p class="card-text"><?php echo $info->isi_informasi ?></p>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- Form Kontak -->
<form id="kontak" method="post" action="<?php echo base_url('landing_page/kirim_pesan') ?>">
  <div class="row m-4">
    <div class="col-md-8">
      <div class="alert alert-primary">
        <i class="fas fa-envelope-open-text"></i> HUBUNGI KAMI
      </div>

      <?php echo $this->session->flashdata('pesan') ?>

      <div class="form-group">
        <label>Nama</label>
        <input type="text" name="nama" class="form-control">
        <?php echo form_error('nama', '<div class="text-danger small">', '</div>') ?>
      </div>

      <div class="form-group">
        <label>Email</label>
        <input type="text" name="email" class="form-control">
        <?php echo form_error('email', '<div class="text-danger small">', '</div>') ?>
      </div>

      <div class="form-group">
        <label>Pesan</label>
        <textarea type="text" name="pesan" class="form-control" rows="5"></textarea>
        <?php echo form_error('pesan', '<div class="text-danger small">', '</div>') ?>
      </div>

      <button type="submit" class="btn btn-primary">Kirim</button>
    </div>
  </div>
</form>
