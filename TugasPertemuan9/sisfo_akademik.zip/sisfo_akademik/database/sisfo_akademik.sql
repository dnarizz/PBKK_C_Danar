-- Database: `sisfo_akademik`
CREATE DATABASE IF NOT EXISTS `sisfo_akademik` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `sisfo_akademik`;

-- --------------------------------------------------------
-- Struktur dari tabel `user`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `level` enum('admin','user') NOT NULL,
  `blokir` enum('N','Y') NOT NULL DEFAULT 'N',
  `id_sessions` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `user` (`id`, `username`, `password`, `email`, `level`, `blokir`, `id_sessions`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin@kampus.ac.id', 'admin', 'N', 'd41d8cd98f00b204e9800998ecf8427e'),
(2, 'mahasiswa', '5787be38ee03a9ae5360f54d9026465f', 'mahasiswa@kampus.ac.id', 'user', 'N', 'd41d8cd98f00b204e9800998ecf8427e');

-- --------------------------------------------------------
-- Struktur dari tabel `jurusan`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `jurusan`;
CREATE TABLE `jurusan` (
  `id_jurusan` int(11) NOT NULL AUTO_INCREMENT,
  `kode_jurusan` varchar(10) NOT NULL,
  `nama_jurusan` varchar(50) NOT NULL,
  PRIMARY KEY (`id_jurusan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `jurusan` (`id_jurusan`, `kode_jurusan`, `nama_jurusan`) VALUES
(1, 'TI', 'Teknik Informatika'),
(2, 'SI', 'Sistem Informasi'),
(3, 'MB', 'Manajemen Bisnis');

-- --------------------------------------------------------
-- Struktur dari tabel `prodi`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `prodi`;
CREATE TABLE `prodi` (
  `id_prodi` int(11) NOT NULL AUTO_INCREMENT,
  `kode_prodi` varchar(20) NOT NULL,
  `nama_prodi` varchar(50) NOT NULL,
  `nama_jurusan` varchar(50) NOT NULL,
  PRIMARY KEY (`id_prodi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `prodi` (`id_prodi`, `kode_prodi`, `nama_prodi`, `nama_jurusan`) VALUES
(1, 'RPL', 'Rekayasa Perangkat Lunak', 'Teknik Informatika'),
(2, 'TKJ', 'Teknik Komputer dan Jaringan', 'Teknik Informatika'),
(3, 'SIA', 'Sistem Informasi Akuntansi', 'Sistem Informasi'),
(4, 'MGT', 'Manajemen Perusahaan', 'Manajemen Bisnis');

-- --------------------------------------------------------
-- Struktur dari tabel `matakuliah`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `matakuliah`;
CREATE TABLE `matakuliah` (
  `kode_matakuliah` varchar(10) NOT NULL,
  `nama_matakuliah` varchar(100) NOT NULL,
  `sks` int(5) NOT NULL,
  `semester` int(5) NOT NULL,
  `nama_prodi` varchar(50) NOT NULL,
  PRIMARY KEY (`kode_matakuliah`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `matakuliah` (`kode_matakuliah`, `nama_matakuliah`, `sks`, `semester`, `nama_prodi`) VALUES
('MK001', 'Pemrograman Berbasis Kerangka Kerja', 3, 5, 'Rekayasa Perangkat Lunak'),
('MK002', 'Basis Data Lanjut', 3, 3, 'Rekayasa Perangkat Lunak'),
('MK003', 'Algoritma dan Struktur Data', 4, 2, 'Rekayasa Perangkat Lunak'),
('MK004', 'Rekayasa Perangkat Lunak', 3, 4, 'Rekayasa Perangkat Lunak'),
('MK005', 'Jaringan Komputer', 3, 3, 'Teknik Komputer dan Jaringan'),
('MK006', 'Sistem Informasi Manajemen', 3, 4, 'Sistem Informasi Akuntansi');

-- --------------------------------------------------------
-- Struktur dari tabel `mahasiswa`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `mahasiswa`;
CREATE TABLE `mahasiswa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nim` varchar(20) NOT NULL,
  `nama_lengkap` varchar(120) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `email` varchar(120) NOT NULL,
  `telepon` varchar(20) NOT NULL,
  `tempat_lahir` varchar(120) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `nama_prodi` varchar(50) NOT NULL,
  `photo` varchar(255) NOT NULL DEFAULT 'default.jpg',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `mahasiswa` (`id`, `nim`, `nama_lengkap`, `alamat`, `email`, `telepon`, `tempat_lahir`, `tanggal_lahir`, `jenis_kelamin`, `nama_prodi`, `photo`) VALUES
(1, '1219001', 'Ahmad Fauzi', 'Jl. Merdeka No. 10, Surabaya', 'ahmad.fauzi@mhs.kampus.ac.id', '081234567801', 'Surabaya', '2003-04-15', 'Laki-laki', 'Rekayasa Perangkat Lunak', 'default.jpg'),
(2, '1219002', 'Siti Nurhaliza', 'Jl. Sudirman No. 25, Sidoarjo', 'siti.nurhaliza@mhs.kampus.ac.id', '081234567802', 'Sidoarjo', '2003-08-22', 'Perempuan', 'Rekayasa Perangkat Lunak', 'default.jpg'),
(3, '1219003', 'Budi Santoso', 'Jl. Diponegoro No. 45, Malang', 'budi.santoso@mhs.kampus.ac.id', '081234567803', 'Malang', '2002-11-10', 'Laki-laki', 'Teknik Komputer dan Jaringan', 'default.jpg'),
(4, '1219004', 'Dewi Lestari', 'Jl. Ahmad Yani No. 88, Gresik', 'dewi.lestari@mhs.kampus.ac.id', '081234567804', 'Gresik', '2003-01-30', 'Perempuan', 'Sistem Informasi Akuntansi', 'default.jpg');

-- --------------------------------------------------------
-- Struktur dari tabel `tahun_akademik`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `tahun_akademik`;
CREATE TABLE `tahun_akademik` (
  `id_thn_akad` int(11) NOT NULL AUTO_INCREMENT,
  `tahun_akademik` varchar(20) NOT NULL,
  `semester` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`id_thn_akad`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `tahun_akademik` (`id_thn_akad`, `tahun_akademik`, `semester`, `status`) VALUES
(1, '2025/2026', 'Ganjil', 'Aktif'),
(2, '2025/2026', 'Genap', 'Aktif');

-- --------------------------------------------------------
-- Struktur dari tabel `krs`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `krs`;
CREATE TABLE `krs` (
  `id_krs` int(11) NOT NULL AUTO_INCREMENT,
  `id_thn_akad` int(10) NOT NULL,
  `nim` varchar(20) NOT NULL,
  `kode_matakuliah` varchar(10) NOT NULL,
  `nilai` varchar(3) NOT NULL DEFAULT '',
  PRIMARY KEY (`id_krs`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `krs` (`id_krs`, `id_thn_akad`, `nim`, `kode_matakuliah`, `nilai`) VALUES
(1, 1, '1219001', 'MK001', 'A'),
(2, 1, '1219001', 'MK002', 'B'),
(3, 1, '1219001', 'MK003', 'A'),
(4, 1, '1219002', 'MK001', 'A'),
(5, 1, '1219002', 'MK002', 'A');

-- --------------------------------------------------------
-- Struktur dari tabel `transkrip_nilai`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `transkrip_nilai`;
CREATE TABLE `transkrip_nilai` (
  `id_transkrip` int(11) NOT NULL AUTO_INCREMENT,
  `nim` varchar(20) NOT NULL,
  `kode_matakuliah` varchar(15) NOT NULL,
  `nilai` varchar(15) NOT NULL,
  PRIMARY KEY (`id_transkrip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `transkrip_nilai` (`id_transkrip`, `nim`, `kode_matakuliah`, `nilai`) VALUES
(1, '1219001', 'MK001', 'A'),
(2, '1219001', 'MK002', 'B'),
(3, '1219001', 'MK003', 'A');

-- --------------------------------------------------------
-- Struktur dari tabel `identitas`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `identitas`;
CREATE TABLE `identitas` (
  `id_identitas` int(11) NOT NULL AUTO_INCREMENT,
  `judul_website` varchar(100) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telp` varchar(50) NOT NULL,
  PRIMARY KEY (`id_identitas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `identitas` (`id_identitas`, `judul_website`, `alamat`, `email`, `telp`) VALUES
(1, 'UNIVERSITAS TEKNOLOGI NUSANTARA', 'Jl. Raya Kampus ITS Sukolilo, Surabaya 60111', 'info@utn.ac.id', '(031) 5947280');

-- --------------------------------------------------------
-- Struktur dari tabel `tentang_kampus`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `tentang_kampus`;
CREATE TABLE `tentang_kampus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sejarah` varchar(1000) NOT NULL,
  `visi` varchar(500) NOT NULL,
  `misi` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `tentang_kampus` (`id`, `sejarah`, `visi`, `misi`) VALUES
(1, 'Universitas Teknologi Nusantara didirikan sebagai institusi pendidikan tinggi unggulan di bidang teknologi informasi, sains, dan manajemen bisnis yang berkomitmen mencetak lulusan berdaya saing global dan berintegritas tinggi.', 'Menjadi Universitas Unggul Berstandar Internasional dalam Pengembangan Ilmu Pengetahuan, Teknologi, dan Bisnis Digital pada Tahun 2035.', 'Menyelenggarakan pendidikan tinggi berkualitas di bidang teknologi dan bisnis; Melaksanakan penelitian inovatif yang bermanfaat bagi masyarakat; Mengembangkan kerja sama strategis dengan industri nasional dan internasional.');

-- --------------------------------------------------------
-- Struktur dari tabel `informasi`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `informasi`;
CREATE TABLE `informasi` (
  `id_informasi` int(11) NOT NULL AUTO_INCREMENT,
  `icon` varchar(100) NOT NULL,
  `judul_informasi` varchar(100) NOT NULL,
  `isi_informasi` varchar(500) NOT NULL,
  PRIMARY KEY (`id_informasi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `informasi` (`id_informasi`, `icon`, `judul_informasi`, `isi_informasi`) VALUES
(1, 'fas fa-user-graduate', 'Penerimaan Mahasiswa Baru', 'Pendaftaran Mahasiswa Baru Tahun Akademik 2025/2026 Gelombang I telah dibuka. Daftar segera melalui portal admisi kampus.'),
(2, 'fas fa-calendar-check', 'Pengisian KRS Online', 'Pengisian Kartu Rencana Studi (KRS) Semester Ganjil Tahun Akademik 2025/2026 dibuka mulai tanggal 1 hingga 15 Agustus.'),
(3, 'fas fa-award', 'Beasiswa Prestasi Akademik', 'Pendaftaran Beasiswa Unggulan dan Beasiswa Prestasi Akademik dibuka bagi mahasiswa aktif minimal semester 3 dengan IPK >= 3.50.');

-- --------------------------------------------------------
-- Struktur dari tabel `hubungi`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `hubungi`;
CREATE TABLE `hubungi` (
  `id_hubungi` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pesan` varchar(500) NOT NULL,
  PRIMARY KEY (`id_hubungi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `hubungi` (`id_hubungi`, `nama`, `email`, `pesan`) VALUES
(1, 'Rizky Pratama', 'rizky.pratama@gmail.com', 'Halo Admin, saya ingin menanyakan jadwal pendaftaran mahasiswa baru jalur prestasi tahun ini. Terima kasih.');

-- --------------------------------------------------------
-- Struktur dari tabel `dosen`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `dosen`;
CREATE TABLE `dosen` (
  `id_dosen` int(11) NOT NULL AUTO_INCREMENT,
  `nidn` varchar(50) NOT NULL,
  `nama_dosen` varchar(100) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telp` varchar(20) NOT NULL,
  `photo` varchar(255) NOT NULL DEFAULT 'default.jpg',
  PRIMARY KEY (`id_dosen`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `dosen` (`id_dosen`, `nidn`, `nama_dosen`, `alamat`, `jenis_kelamin`, `email`, `telp`, `photo`) VALUES
(1, '0015048001', 'Dr. Hendra Wijaya, S.Kom., M.Kom.', 'Jl. Raya ITS Sukolilo No. 12, Surabaya', 'Laki-laki', 'hendra.wijaya@kampus.ac.id', '081234560001', 'default.jpg'),
(2, '0022088502', 'Rina Kusumawati, S.T., M.T.', 'Jl. Dharmahusada Indah No. 45, Surabaya', 'Perempuan', 'rina.kusumawati@kampus.ac.id', '081234560002', 'default.jpg'),
(3, '0010118803', 'Bambang Prasetyo, S.Si., M.Cs.', 'Jl. Kertajaya Indah No. 8, Surabaya', 'Laki-laki', 'bambang.prasetyo@kampus.ac.id', '081234560003', 'default.jpg');
