<div class="container-fluid">
    <h3><i class="fas fa-edit"></i> EDIT DATA BARANG</h3>

    <?php foreach ($barang as $brg) : ?>

        <form method="post" action="<?php echo base_url() . 'admin/data_barang/update' ?>" enctype="multipart/form-data">

            <div class="form-group">
                <label>Nama Barang</label>
                <input type="text" name="nama_brg" class="form-control" value="<?php echo $brg->nama_brg ?>" required>
            </div>

            <div class="form-group">
                <label>Keterangan</label>
                <input type="hidden" name="id_brg" class="form-control" value="<?php echo $brg->id_brg ?>">
                <input type="text" name="keterangan" class="form-control" value="<?php echo $brg->keterangan ?>" required>
            </div>

            <div class="form-group">
                <label>Kategori</label>
                <select class="form-control" name="kategori">
                    <option value="Elektronik" <?php echo ($brg->kategori == 'Elektronik') ? 'selected' : ''; ?>>Elektronik</option>
                    <option value="Pakaian Pria" <?php echo ($brg->kategori == 'Pakaian Pria') ? 'selected' : ''; ?>>Pakaian Pria</option>
                    <option value="Pakaian Wanita" <?php echo ($brg->kategori == 'Pakaian Wanita') ? 'selected' : ''; ?>>Pakaian Wanita</option>
                    <option value="Pakaian Anak-anak" <?php echo ($brg->kategori == 'Pakaian Anak-anak') ? 'selected' : ''; ?>>Pakaian Anak-anak</option>
                    <option value="Peralatan Olahraga" <?php echo ($brg->kategori == 'Peralatan Olahraga') ? 'selected' : ''; ?>>Peralatan Olahraga</option>
                </select>
            </div>

            <div class="form-group">
                <label>Harga</label>
                <input type="number" name="harga" class="form-control" value="<?php echo $brg->harga ?>" required>
            </div>

            <div class="form-group">
                <label>Stok</label>
                <input type="number" name="stok" class="form-control" value="<?php echo $brg->stok ?>" required>
            </div>

            <div class="form-group">
                <label>Gambar Produk (Kosongkan jika tidak diubah)</label>
                <input type="file" name="gambar" class="form-control">
            </div>

            <button type="submit" class="btn btn-primary btn-sm mt-3">Simpan</button>
            <a href="<?php echo base_url('admin/data_barang/index') ?>" class="btn btn-danger btn-sm mt-3">Batal</a>

        </form>

    <?php endforeach; ?>
</div>
