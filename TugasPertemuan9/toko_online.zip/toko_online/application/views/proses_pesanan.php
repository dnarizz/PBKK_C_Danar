<div class="container-fluid">
    <div class="alert alert-success">
        <p class="text-center align-middle">Selamat, Pesanan Anda telah Berhasil diproses!!!</p>
    </div>
    <div class="text-center">
        <a href="<?php echo base_url('welcome') ?>" class="btn btn-sm btn-primary">Kembali ke Beranda</a>
    </div>
</div>
