-- ============================================================
-- Database: toko_online
-- Proyek 2: Aplikasi Toko Online (E-Commerce) CodeIgniter 3
-- Referensi: Framework Indonesia (SB Admin 2 + Bootstrap 4)
-- ============================================================

CREATE DATABASE IF NOT EXISTS `toko_online` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `toko_online`;

-- --------------------------------------------------------
-- Struktur dari tabel `tb_barang`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `tb_barang`;
CREATE TABLE `tb_barang` (
  `id_brg` int(11) NOT NULL AUTO_INCREMENT,
  `nama_brg` varchar(120) NOT NULL,
  `keterangan` varchar(225) NOT NULL,
  `kategori` varchar(60) NOT NULL,
  `harga` int(11) NOT NULL,
  `stok` int(4) NOT NULL,
  `gambar` text NOT NULL,
  PRIMARY KEY (`id_brg`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `tb_barang` (`id_brg`, `nama_brg`, `keterangan`, `kategori`, `harga`, `stok`, `gambar`) VALUES
(1, 'Sepatu Sneakers', 'Sepatu Pria Original All Star nyaman dipakai harian', 'Pakaian Pria', 300000, 10, 'sepatu.svg'),
(2, 'Kamera DSLR', 'Kamera DSLR Canon EOS 200D Lensa Kit 18-55mm', 'Elektronik', 5900000, 9, 'kamera.svg'),
(3, 'Samsung Galaxy A20', 'Smartphone Android Samsung Galaxy A20 RAM 4/64GB', 'Elektronik', 3400000, 30, 'hp.svg'),
(4, 'Laptop Asus VivoBook', 'Laptop Asus Core i5 RAM 8GB SSD 512GB Full HD', 'Elektronik', 7800000, 15, 'laptop.svg'),
(5, 'Jaket Bomber Pria', 'Jaket Bomber Pria Casual bahan taslan waterproof', 'Pakaian Pria', 250000, 20, 'jaket_pria.svg'),
(6, 'Gaun Dress Wanita', 'Gaun Pesta Wanita Modern bahan satin lembut', 'Pakaian Wanita', 450000, 12, 'gaun_wanita.svg'),
(7, 'Setelan Baju Anak', 'Setelan Kaos dan Celana Anak bahan katun combed 30s', 'Pakaian Anak-anak', 120000, 25, 'baju_anak.svg'),
(8, 'Bola Basket Molten', 'Bola Basket Molten GG7X Original Size 7 Indoor/Outdoor', 'Peralatan Olahraga', 350000, 18, 'bola_basket.svg');

-- --------------------------------------------------------
-- Struktur dari tabel `tb_user`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `tb_user`;
CREATE TABLE `tb_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `role_id` tinyint(1) NOT NULL COMMENT '1=Admin, 2=Customer',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `tb_user` (`id`, `nama`, `username`, `password`, `role_id`) VALUES
(1, 'Administrator Toko', 'admin', '123', 1),
(2, 'Pelanggan Budi', 'user', '123', 2);

-- --------------------------------------------------------
-- Struktur dari tabel `tb_invoice`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `tb_invoice`;
CREATE TABLE `tb_invoice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(56) NOT NULL,
  `alamat` varchar(225) NOT NULL,
  `tgl_pesan` datetime NOT NULL,
  `batas_bayar` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `tb_invoice` (`id`, `nama`, `alamat`, `tgl_pesan`, `batas_bayar`) VALUES
(1, 'Budi Santoso', 'Jl. Raya ITS Sukolilo No. 10, Surabaya, Jawa Timur', '2026-11-05 10:00:00', '2026-11-06 10:00:00');

-- --------------------------------------------------------
-- Struktur dari tabel `tb_pesanan`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `tb_pesanan`;
CREATE TABLE `tb_pesanan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_invoice` int(11) NOT NULL,
  `id_brg` int(11) NOT NULL,
  `nama_brg` varchar(50) NOT NULL,
  `jumlah` int(3) NOT NULL,
  `harga` int(10) NOT NULL,
  `pilihan` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `tb_pesanan` (`id`, `id_invoice`, `id_brg`, `nama_brg`, `jumlah`, `harga`, `pilihan`) VALUES
(1, 1, 1, 'Sepatu Sneakers', 1, 300000, ''),
(2, 1, 3, 'Samsung Galaxy A20', 1, 3400000, '');

-- --------------------------------------------------------
-- Trigger `pesanan_penjualan` untuk mengurangi stok barang otomatis
-- --------------------------------------------------------
DROP TRIGGER IF EXISTS `pesanan_penjualan`;
DELIMITER $$
CREATE TRIGGER `pesanan_penjualan` AFTER INSERT ON `tb_pesanan` FOR EACH ROW BEGIN
    UPDATE tb_barang SET stok = stok - NEW.jumlah
    WHERE id_brg = NEW.id_brg;
END
$$
DELIMITER ;
