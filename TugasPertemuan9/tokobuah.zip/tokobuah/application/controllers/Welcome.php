<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Editable student biodata profile for Latihan 1 (Tahap 2-1).
	 *
	 * @return array
	 */
	private function _getBiodata()
	{
		return array(
			'nama'        => 'Danar Rizkia Yuda',
			'nrp'         => '5025241128',
			'kelas'       => 'PBKK C',
			'prodi'       => 'Teknik Informatika',
			'mata_kuliah' => 'Pemrograman Berbasis Kerangka Kerja (PBKK C)',
			'kampus'      => 'Institut Teknologi Sepuluh Nopember (ITS)',
			'moto'        => 'Belajar CodeIgniter 3 MVC dengan terstruktur dan konsisten.'
		);
	}

	/**
	 * Display Welcome page with student biodata profile.
	 */
	public function index()
	{
		$data = array(
			'page_title'  => SITE_NAME . ' - Welcome & Biodata',
			'active_menu' => 'home',
			'biodata'     => $this->_getBiodata()
		);
		$this->load->view('welcome_message', $data);
	}

	/**
	 * Display About page (Tahap 2-2).
	 */
	public function about()
	{
		$data = array(
			'page_title'  => SITE_NAME . ' - About Us',
			'active_menu' => 'about',
			'biodata'     => $this->_getBiodata()
		);
		$this->load->view('about', $data);
	}

	/**
	 * Display Contact page (Tahap 2-2).
	 */
	public function contact()
	{
		$data = array(
			'page_title'  => SITE_NAME . ' - Contact Us',
			'active_menu' => 'contact',
			'biodata'     => $this->_getBiodata()
		);
		$this->load->view('contact', $data);
	}
}
