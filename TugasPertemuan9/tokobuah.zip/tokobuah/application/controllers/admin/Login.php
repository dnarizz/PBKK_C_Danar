<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('user_model');
		$this->load->library('form_validation');
	}

	/**
	 * Render admin login form and process login POST requests.
	 */
	public function index()
	{
		if (!$this->user_model->isNotLogin()) {
			redirect(site_url('admin'));
		}

		if ($this->input->post()) {
			if ($this->user_model->doLogin()) {
				redirect(site_url('admin'));
			}
			$this->session->set_flashdata('error', 'Username/Email atau Password salah!');
		}

		$this->load->view('admin/login_page');
	}

	/**
	 * Destroy session and redirect to admin login page.
	 */
	public function logout()
	{
		$this->session->sess_destroy();
		redirect(site_url('admin/login'));
	}
}
