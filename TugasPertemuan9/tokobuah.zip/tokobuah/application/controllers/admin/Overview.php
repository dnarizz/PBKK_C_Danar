<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Overview extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('user_model');
		$this->load->model('product_model');

		if ($this->user_model->isNotLogin()) {
			redirect(site_url('admin/login'));
		}
	}

	/**
	 * Display admin overview dashboard with summary cards, chart, and products table.
	 */
	public function index()
	{
		$products = $this->product_model->getAll();
		$total_price = 0;
		foreach ($products as $item) {
			$total_price += (int) $item->price;
		}

		$data = array(
			'products'       => $products,
			'total_products' => count($products),
			'total_users'    => $this->user_model->countAll(),
			'total_price'    => $total_price,
			'avg_price'      => count($products) > 0 ? (int) round($total_price / count($products)) : 0
		);

		$this->load->view('admin/overview', $data);
	}
}
