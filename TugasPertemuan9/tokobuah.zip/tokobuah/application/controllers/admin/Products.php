<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('product_model');
		$this->load->model('user_model');
		$this->load->library('form_validation');

		if ($this->user_model->isNotLogin()) {
			redirect(site_url('admin/login'));
		}
	}

	/**
	 * Display list of all products.
	 */
	public function index()
	{
		$data['products'] = $this->product_model->getAll();
		$this->load->view('admin/product/list', $data);
	}

	/**
	 * Add a new product with optional photo upload.
	 */
	public function add()
	{
		$product = $this->product_model;
		$validation = $this->form_validation;
		$validation->set_rules($product->rules());

		if ($validation->run()) {
			$product->save();
			$this->session->set_flashdata('success', 'Berhasil disimpan');
		}

		$this->load->view('admin/product/new_form');
	}

	/**
	 * Edit an existing product by id.
	 *
	 * @param string|null $id
	 */
	public function edit($id = null)
	{
		if (!isset($id)) {
			redirect('admin/products');
		}

		$product = $this->product_model;
		$validation = $this->form_validation;
		$validation->set_rules($product->rules());

		if ($validation->run()) {
			$product->update();
			$this->session->set_flashdata('success', 'Berhasil disimpan');
		}

		$data['product'] = $product->getById($id);
		if (!$data['product']) {
			show_404();
		}

		$this->load->view('admin/product/edit_form', $data);
	}

	/**
	 * Delete a product by id.
	 *
	 * @param string|null $id
	 */
	public function delete($id = null)
	{
		if (!isset($id)) {
			show_404();
		}

		if ($this->product_model->delete($id)) {
			$this->session->set_flashdata('success', 'Berhasil dihapus');
			redirect(site_url('admin/products'));
		}
	}
}
