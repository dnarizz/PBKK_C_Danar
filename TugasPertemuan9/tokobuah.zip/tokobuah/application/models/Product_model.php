<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_model extends CI_Model {

	private $_table = 'products';

	public $product_id;
	public $name;
	public $price;
	public $image = 'default.jpg';
	public $description;

	/**
	 * Form validation rules for product create and update.
	 *
	 * @return array
	 */
	public function rules()
	{
		return array(
			array(
				'field' => 'name',
				'label' => 'Name',
				'rules' => 'required'
			),
			array(
				'field' => 'price',
				'label' => 'Price',
				'rules' => 'required|numeric'
			),
			array(
				'field' => 'description',
				'label' => 'Description',
				'rules' => 'required'
			)
		);
	}

	/**
	 * Fetch all products.
	 *
	 * @return array
	 */
	public function getAll()
	{
		return $this->db->get($this->_table)->result();
	}

	/**
	 * Fetch a single product by product_id.
	 *
	 * @param string $id
	 * @return object|null
	 */
	public function getById($id)
	{
		return $this->db->get_where($this->_table, array('product_id' => $id))->row();
	}

	/**
	 * Save a new product from POST input.
	 *
	 * @return bool
	 */
	public function save()
	{
		$this->product_id  = uniqid();
		$this->name        = $this->input->post('name', TRUE);
		$this->price       = (int) $this->input->post('price', TRUE);
		$this->image       = $this->_uploadImage();
		$this->description = $this->input->post('description', TRUE);

		return $this->db->insert($this->_table, $this);
	}

	/**
	 * Update an existing product from POST input.
	 *
	 * @return bool
	 */
	public function update()
	{
		$this->product_id  = $this->input->post('id', TRUE);
		$this->name        = $this->input->post('name', TRUE);
		$this->price       = (int) $this->input->post('price', TRUE);
		$this->description = $this->input->post('description', TRUE);

		$old_image = $this->input->post('old_image', TRUE);
		if (empty($old_image)) {
			$old_image = 'default.jpg';
		}

		if (!empty($_FILES['image']['name'])) {
			$uploaded = $this->_uploadImage();
			if ($uploaded !== 'default.jpg') {
				if ($old_image !== 'default.jpg' && $old_image !== $uploaded) {
					$this->_deleteFile($old_image);
				}
				$this->image = $uploaded;
			} else {
				$this->image = $old_image;
			}
		} else {
			$this->image = $old_image;
		}

		return $this->db->update($this->_table, $this, array('product_id' => $this->product_id));
	}

	/**
	 * Delete product row and its uploaded image file.
	 *
	 * @param string $id
	 * @return bool
	 */
	public function delete($id)
	{
		$this->_deleteImage($id);
		return $this->db->delete($this->_table, array('product_id' => $id));
	}

	/**
	 * Upload product image using CodeIgniter upload library.
	 *
	 * @return string
	 */
	private function _uploadImage()
	{
		if (empty($_FILES['image']['name'])) {
			return 'default.jpg';
		}

		$config = array(
			'upload_path'   => './upload/product/',
			'allowed_types' => 'gif|jpg|png|jpeg',
			'file_name'     => $this->product_id,
			'overwrite'     => TRUE,
			'max_size'      => 2048
		);

		$this->load->library('upload', $config);
		$this->upload->initialize($config);

		if ($this->upload->do_upload('image')) {
			return $this->upload->data('file_name');
		}

		return 'default.jpg';
	}

	/**
	 * Delete image file associated with a product id if not default.jpg.
	 *
	 * @param string $id
	 */
	private function _deleteImage($id)
	{
		$product = $this->getById($id);
		if ($product && $product->image !== 'default.jpg') {
			$this->_deleteFile($product->image);
		}
	}

	/**
	 * Remove uploaded product image file matching base filename.
	 *
	 * @param string $image_name
	 */
	private function _deleteFile($image_name)
	{
		$filename = pathinfo($image_name, PATHINFO_FILENAME);
		if ($filename !== '' && $filename !== 'default') {
			$files = glob(FCPATH . 'upload/product/' . $filename . '.*');
			if (is_array($files)) {
				array_map('unlink', $files);
			}
		}
	}
}
