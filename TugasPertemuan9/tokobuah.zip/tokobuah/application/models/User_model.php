<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

	private $_table = 'users';

	/**
	 * Authenticate admin user by email or username and password.
	 *
	 * @return bool
	 */
	public function doLogin()
	{
		$email    = trim((string) $this->input->post('email', TRUE));
		$password = (string) $this->input->post('password');

		if ($email === '' || $password === '') {
			return FALSE;
		}

		$this->db->where('is_active', 1);
		$this->db->group_start();
		$this->db->where('email', $email);
		$this->db->or_where('username', $email);
		$this->db->group_end();
		$user = $this->db->get($this->_table)->row();

		if ($user && $user->role === 'admin' && password_verify($password, $user->password)) {
			$session_user = (object) array(
				'user_id'    => $user->user_id,
				'username'   => $user->username,
				'email'      => $user->email,
				'full_name'  => $user->full_name,
				'role'       => $user->role,
				'photo'      => $user->photo
			);
			$this->session->set_userdata(array('user_logged' => $session_user));
			$this->_updateLastLogin($user->user_id);
			return TRUE;
		}

		return FALSE;
	}

	/**
	 * Check whether no admin user is currently logged in.
	 *
	 * @return bool
	 */
	public function isNotLogin()
	{
		return $this->session->userdata('user_logged') === NULL;
	}

	/**
	 * Count all registered users.
	 *
	 * @return int
	 */
	public function countAll()
	{
		return (int) $this->db->count_all($this->_table);
	}

	/**
	 * Update user's last_login timestamp.
	 *
	 * @param int $user_id
	 */
	private function _updateLastLogin($user_id)
	{
		$this->db->where('user_id', (int) $user_id);
		$this->db->update($this->_table, array('last_login' => date('Y-m-d H:i:s')));
	}
}
