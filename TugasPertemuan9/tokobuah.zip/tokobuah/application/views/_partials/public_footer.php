</main>

<footer class="bg-white border-top py-3 mt-auto">
	<div class="container text-center text-muted small">
		<span>Copyright &copy; <?php echo SITE_NAME . ' ' . date('Y'); ?> &mdash; PBKK Latihan 1 CodeIgniter 3</span>
	</div>
</footer>

<script src="<?php echo base_url('assets/vendor/jquery/jquery.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/vendor/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/sb-admin-2.min.js'); ?>"></script>
</body>
</html>
