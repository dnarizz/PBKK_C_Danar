<!DOCTYPE html>
<html lang="id">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title><?php echo html_escape(isset($page_title) ? $page_title : SITE_NAME); ?></title>
	<link href="<?php echo base_url('assets/vendor/fontawesome-free/css/all.min.css'); ?>" rel="stylesheet" type="text/css">
	<link href="<?php echo base_url('assets/css/sb-admin-2.min.css'); ?>" rel="stylesheet">
</head>
<body class="bg-light d-flex flex-column min-vh-100">

<nav class="navbar navbar-expand-lg navbar-dark bg-success shadow-sm">
	<div class="container">
		<a class="navbar-brand font-weight-bold" href="<?php echo site_url('/'); ?>">
			<i class="fas fa-apple-alt mr-2"></i><?php echo SITE_NAME; ?>
		</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#publicNavbar" aria-controls="publicNavbar" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>

		<div class="collapse navbar-collapse" id="publicNavbar">
			<ul class="navbar-nav mr-auto">
				<li class="nav-item <?php echo (isset($active_menu) && $active_menu === 'home') ? 'active' : ''; ?>">
					<a class="nav-link" href="<?php echo site_url('/'); ?>">Home</a>
				</li>
				<li class="nav-item <?php echo (isset($active_menu) && $active_menu === 'about') ? 'active' : ''; ?>">
					<a class="nav-link" href="<?php echo site_url('about'); ?>">About</a>
				</li>
				<li class="nav-item <?php echo (isset($active_menu) && $active_menu === 'contact') ? 'active' : ''; ?>">
					<a class="nav-link" href="<?php echo site_url('contact'); ?>">Contact</a>
				</li>
			</ul>
			<ul class="navbar-nav ml-auto">
				<li class="nav-item">
					<a class="btn btn-outline-light btn-sm" href="<?php echo site_url('admin/login'); ?>">
						<i class="fas fa-sign-in-alt mr-1"></i> Admin Panel
					</a>
				</li>
			</ul>
		</div>
	</div>
</nav>

<main class="container py-5 flex-grow-1">
