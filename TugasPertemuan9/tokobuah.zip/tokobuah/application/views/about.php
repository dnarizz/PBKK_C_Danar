<?php $this->load->view('_partials/public_header'); ?>

<div class="card shadow-sm">
	<div class="card-header bg-success text-white">
		<h4 class="mb-0"><i class="fas fa-info-circle mr-2"></i>About <?php echo SITE_NAME; ?></h4>
	</div>
	<div class="card-body">
		<p class="lead">
			Halaman ini merupakan implementasi method <code>about()</code> pada controller <code>Welcome</code> yang diakses melalui route <code>/about</code> maupun <code>/welcome/about</code> (Latihan 1 Tahap 2-2).
		</p>
		<hr>
		<div class="row">
			<div class="col-md-6 mb-3">
				<h5 class="font-weight-bold text-success">Tentang Proyek Tokobuah</h5>
				<p class="text-muted">
					<strong><?php echo SITE_NAME; ?></strong> adalah studi kasus pengenalan framework CodeIgniter 3 yang menerapkan pola arsitektur <strong>Model-View-Controller (MVC)</strong>, template Bootstrap SB Admin dengan view partials, operasi CRUD produk buah, penanganan upload file gambar, serta autentikasi pengguna.
				</p>
			</div>
			<div class="col-md-6 mb-3">
				<h5 class="font-weight-bold text-success">Informasi Pengembang</h5>
				<ul class="list-unstyled text-muted mb-0">
					<li><strong>Nama:</strong> <?php echo html_escape($biodata['nama']); ?></li>
					<li><strong>NRP:</strong> <?php echo html_escape($biodata['nrp']); ?></li>
					<li><strong>Kelas:</strong> <?php echo html_escape($biodata['kelas']); ?></li>
					<li><strong>Mata Kuliah:</strong> <?php echo html_escape($biodata['mata_kuliah']); ?></li>
				</ul>
			</div>
		</div>
		<a href="<?php echo site_url('/'); ?>" class="btn btn-outline-success btn-sm mt-2">
			<i class="fas fa-arrow-left mr-1"></i> Kembali ke Home
		</a>
	</div>
</div>

<?php $this->load->view('_partials/public_footer'); ?>
