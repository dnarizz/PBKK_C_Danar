<?php
$logged_user = $this->session->userdata('user_logged');
?>
<!-- Logout Modal -->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="logoutModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="logoutModalLabel">Konfirmasi Logout</h5>
				<button class="close" type="button" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">Pilih "Logout" jika Anda yakin ingin mengakhiri sesi admin saat ini.</div>
			<div class="modal-footer">
				<button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
				<a class="btn btn-success" href="<?php echo site_url('admin/login/logout'); ?>">Logout</a>
			</div>
		</div>
	</div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="deleteModalLabel">Apakah Anda yakin?</h5>
				<button class="close" type="button" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">Data produk yang dihapus tidak akan bisa dikembalikan.</div>
			<div class="modal-footer">
				<button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
				<a id="btn-delete" class="btn btn-danger" href="#">Delete</a>
			</div>
		</div>
	</div>
</div>

<!-- User Profile Modal -->
<div class="modal fade" id="userProfileModal" tabindex="-1" role="dialog" aria-labelledby="userProfileModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header bg-success text-white">
				<h5 class="modal-title" id="userProfileModalLabel"><i class="fas fa-user-shield mr-2"></i>Informasi Akun Admin</h5>
				<button class="close text-white" type="button" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<?php if ($logged_user): ?>
					<p class="mb-1"><strong>Nama Lengkap:</strong> <?php echo html_escape($logged_user->full_name); ?></p>
					<p class="mb-1"><strong>Username:</strong> <?php echo html_escape($logged_user->username); ?></p>
					<p class="mb-1"><strong>Email:</strong> <?php echo html_escape($logged_user->email); ?></p>
					<p class="mb-0"><strong>Role:</strong> <span class="badge badge-success"><?php echo html_escape($logged_user->role); ?></span></p>
				<?php endif; ?>
			</div>
			<div class="modal-footer">
				<button class="btn btn-secondary btn-sm" type="button" data-dismiss="modal">Tutup</button>
			</div>
		</div>
	</div>
</div>
