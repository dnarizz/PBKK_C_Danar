<?php
$logged_user = $this->session->userdata('user_logged');
$display_name = ($logged_user && isset($logged_user->full_name)) ? $logged_user->full_name : 'Admin';
?>
<nav class="navbar navbar-expand navbar-dark bg-success static-top shadow-sm">
	<a class="navbar-brand font-weight-bold mr-2" href="<?php echo site_url('admin'); ?>">
		<i class="fas fa-apple-alt mr-1"></i><?php echo SITE_NAME; ?>
	</a>

	<button class="btn btn-link btn-sm text-white order-1 order-sm-0 mr-2" id="sidebarToggle" type="button" aria-label="Toggle Sidebar">
		<i class="fas fa-bars"></i>
	</button>

	<!-- Navbar Search -->
	<form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0" action="<?php echo site_url('admin/products'); ?>" method="get">
		<div class="input-group input-group-sm">
			<input type="text" class="form-control border-0" placeholder="Search for..." aria-label="Search">
			<div class="input-group-append">
				<button class="btn btn-light text-success" type="submit">
					<i class="fas fa-search"></i>
				</button>
			</div>
		</div>
	</form>

	<!-- Navbar -->
	<ul class="navbar-nav ml-auto ml-md-0">
		<li class="nav-item dropdown no-arrow mx-1">
			<a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				<i class="fas fa-bell fa-fw"></i>
				<span class="badge badge-danger badge-counter">3+</span>
			</a>
			<div class="dropdown-menu dropdown-menu-right shadow" aria-labelledby="alertsDropdown">
				<h6 class="dropdown-header bg-success text-white">Notifikasi</h6>
				<a class="dropdown-item small" href="<?php echo site_url('admin/products'); ?>">Lihat daftar produk terbaru</a>
				<a class="dropdown-item small" href="<?php echo site_url('admin/products/add'); ?>">Tambah produk buah baru</a>
			</div>
		</li>

		<li class="nav-item dropdown no-arrow mx-1">
			<a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				<i class="fas fa-envelope fa-fw"></i>
				<span class="badge badge-danger badge-counter">7</span>
			</a>
			<div class="dropdown-menu dropdown-menu-right shadow" aria-labelledby="messagesDropdown">
				<h6 class="dropdown-header bg-success text-white">Pesan</h6>
				<a class="dropdown-item small" href="<?php echo site_url('contact'); ?>">Buka halaman kontak publik</a>
			</div>
		</li>

		<li class="nav-item dropdown no-arrow">
			<a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				<i class="fas fa-user-circle fa-fw mr-1"></i>
				<span class="d-none d-sm-inline"><?php echo html_escape($display_name); ?></span>
			</a>
			<div class="dropdown-menu dropdown-menu-right shadow" aria-labelledby="userDropdown">
				<a class="dropdown-item" href="<?php echo site_url('/'); ?>">
					<i class="fas fa-globe fa-sm fa-fw mr-2 text-gray-400"></i> Halaman Publik
				</a>
				<div class="dropdown-divider"></div>
				<a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
					<i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i> Logout
				</a>
			</div>
		</li>
	</ul>
</nav>
