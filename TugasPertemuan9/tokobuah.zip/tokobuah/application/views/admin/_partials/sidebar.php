<?php
$seg2 = (string) $this->uri->segment(2);
$is_overview = ($seg2 === '' || $seg2 === 'overview');
$is_products = ($seg2 === 'products');
?>
<!-- Sidebar -->
<ul class="sidebar navbar-nav bg-dark sidebar-dark accordion" id="accordionSidebar">
	<li class="nav-item <?php echo $is_overview ? 'active' : ''; ?>">
		<a class="nav-link" href="<?php echo site_url('admin'); ?>">
			<i class="fas fa-fw fa-tachometer-alt"></i>
			<span>Overview</span>
		</a>
	</li>

	<li class="nav-item <?php echo $is_products ? 'active' : ''; ?>">
		<a class="nav-link <?php echo $is_products ? '' : 'collapsed'; ?>" href="#" data-toggle="collapse" data-target="#collapseProducts" aria-expanded="<?php echo $is_products ? 'true' : 'false'; ?>" aria-controls="collapseProducts">
			<i class="fas fa-fw fa-boxes"></i>
			<span>Products</span>
		</a>
		<div id="collapseProducts" class="collapse <?php echo $is_products ? 'show' : ''; ?>" data-parent="#accordionSidebar">
			<div class="bg-white py-2 collapse-inner rounded">
				<h6 class="collapse-header">Kelola Produk:</h6>
				<a class="collapse-item <?php echo ($is_products && $this->uri->segment(3) === 'add') ? 'active' : ''; ?>" href="<?php echo site_url('admin/products/add'); ?>">New Product</a>
				<a class="collapse-item <?php echo ($is_products && $this->uri->segment(3) === NULL) ? 'active' : ''; ?>" href="<?php echo site_url('admin/products'); ?>">List Product</a>
			</div>
		</div>
	</li>

	<li class="nav-item">
		<a class="nav-link" href="#" data-toggle="modal" data-target="#userProfileModal">
			<i class="fas fa-fw fa-users"></i>
			<span>Users</span>
		</a>
	</li>

	<li class="nav-item">
		<a class="nav-link" href="<?php echo site_url('/'); ?>">
			<i class="fas fa-fw fa-cog"></i>
			<span>Settings / Publik</span>
		</a>
	</li>

	<hr class="sidebar-divider d-none d-md-block">

	<li class="nav-item">
		<a class="nav-link" href="#" data-toggle="modal" data-target="#logoutModal">
			<i class="fas fa-fw fa-sign-out-alt"></i>
			<span>Logout</span>
		</a>
	</li>
</ul>
