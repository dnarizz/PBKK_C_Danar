<!DOCTYPE html>
<html lang="id">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Login Admin</title>
	<link href="<?php echo base_url('assets/vendor/fontawesome-free/css/all.min.css'); ?>" rel="stylesheet" type="text/css">
	<link href="<?php echo base_url('assets/css/sb-admin-2.min.css'); ?>" rel="stylesheet">
</head>
<body class="bg-light d-flex align-items-center min-vh-100">

<div class="container">
	<div class="row">
		<div class="col-12 col-md-6 mx-auto text-center mt-4">
			<h1 class="h2 font-weight-bold text-dark">Login Admin</h1>
			<p class="lead text-muted">Silahkan masuk ke Panel Admin</p>
		</div>
	</div>

	<div class="row">
		<div class="col-12 col-md-5 mx-auto mt-3 mb-5">
			<div class="card shadow-sm border-0">
				<div class="card-body p-4">
					<?php if ($this->session->flashdata('error')): ?>
						<div class="alert alert-danger alert-dismissible fade show" role="alert">
							<?php echo html_escape($this->session->flashdata('error')); ?>
							<button type="button" class="close" data-dismiss="alert" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
						</div>
					<?php endif; ?>

					<form action="<?php echo site_url('admin/login'); ?>" method="post">
						<div class="form-group">
							<label for="email">Email</label>
							<input type="text" class="form-control" name="email" id="email" placeholder="Pakai username juga bisa.." value="<?php echo set_value('email'); ?>" required autofocus />
						</div>

						<div class="form-group">
							<label for="password">Password</label>
							<input type="password" class="form-control" name="password" id="password" placeholder="Password.." required />
						</div>

						<div class="form-group">
							<div class="d-flex justify-content-between align-items-center">
								<div class="custom-control custom-checkbox">
									<input type="checkbox" class="custom-control-input" name="rememberme" id="rememberme" />
									<label class="custom-control-label" for="rememberme">Ingat Saya</label>
								</div>
								<a href="#" data-toggle="modal" data-target="#forgotModal">Lupa Password?</a>
							</div>
						</div>

						<div class="form-group mb-0">
							<input type="submit" class="btn btn-success w-100" value="Login" />
						</div>
					</form>
				</div>
			</div>

			<div class="text-center mt-3">
				<a href="<?php echo site_url('/'); ?>" class="small text-muted">
					<i class="fas fa-arrow-left mr-1"></i> Kembali ke Halaman Utama
				</a>
			</div>
		</div>
	</div>
</div>

<!-- Lupa Password Modal -->
<div class="modal fade" id="forgotModal" tabindex="-1" role="dialog" aria-labelledby="forgotModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-sm modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header bg-success text-white">
				<h6 class="modal-title" id="forgotModalLabel">Informasi Akun Default</h6>
				<button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body small">
				<p class="mb-2">Gunakan kredensial default berikut untuk login ke panel admin:</p>
				<ul class="mb-0 pl-3">
					<li><strong>Username:</strong> <code>admin</code></li>
					<li><strong>Email:</strong> <code>admin@tokobuah.test</code></li>
					<li><strong>Password:</strong> <code>admin123</code></li>
				</ul>
			</div>
			<div class="modal-footer py-2">
				<button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Tutup</button>
			</div>
		</div>
	</div>
</div>

<script src="<?php echo base_url('assets/vendor/jquery/jquery.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/vendor/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>
</body>
</html>
