<!DOCTYPE html>
<html lang="id">
<head>
	<?php $this->load->view('admin/_partials/head.php'); ?>
</head>
<body id="page-top">

<?php $this->load->view('admin/_partials/navbar.php'); ?>

<div id="wrapper">

	<?php $this->load->view('admin/_partials/sidebar.php'); ?>

	<div id="content-wrapper" class="d-flex flex-column">
		<div id="content" class="pt-4">
			<div class="container-fluid">

				<?php $this->load->view('admin/_partials/breadcrumb.php'); ?>

				<!-- Icon Cards -->
				<div class="row">
					<div class="col-xl-3 col-sm-6 mb-3">
						<div class="card text-white bg-primary o-hidden h-100 shadow-sm">
							<div class="card-body">
								<div class="d-flex justify-content-between align-items-center">
									<div>
										<div class="text-uppercase small font-weight-bold">Total Products</div>
										<div class="h4 mb-0 font-weight-bold"><?php echo (int) $total_products; ?> Item</div>
									</div>
									<i class="fas fa-fw fa-boxes fa-2x text-white-50"></i>
								</div>
							</div>
							<a class="card-footer text-white clearfix small z-1 bg-primary border-top border-light" href="<?php echo site_url('admin/products'); ?>">
								<span class="float-left">View Details</span>
								<span class="float-right"><i class="fas fa-angle-right"></i></span>
							</a>
						</div>
					</div>

					<div class="col-xl-3 col-sm-6 mb-3">
						<div class="card text-white bg-warning o-hidden h-100 shadow-sm">
							<div class="card-body">
								<div class="d-flex justify-content-between align-items-center">
									<div>
										<div class="text-uppercase small font-weight-bold">Total Harga Katalog</div>
										<div class="h5 mb-0 font-weight-bold">Rp <?php echo number_format($total_price, 0, ',', '.'); ?></div>
									</div>
									<i class="fas fa-fw fa-tags fa-2x text-white-50"></i>
								</div>
							</div>
							<a class="card-footer text-white clearfix small z-1 bg-warning border-top border-light" href="<?php echo site_url('admin/products'); ?>">
								<span class="float-left">View Details</span>
								<span class="float-right"><i class="fas fa-angle-right"></i></span>
							</a>
						</div>
					</div>

					<div class="col-xl-3 col-sm-6 mb-3">
						<div class="card text-white bg-success o-hidden h-100 shadow-sm">
							<div class="card-body">
								<div class="d-flex justify-content-between align-items-center">
									<div>
										<div class="text-uppercase small font-weight-bold">Rata-rata Harga</div>
										<div class="h5 mb-0 font-weight-bold">Rp <?php echo number_format($avg_price, 0, ',', '.'); ?></div>
									</div>
									<i class="fas fa-fw fa-shopping-cart fa-2x text-white-50"></i>
								</div>
							</div>
							<a class="card-footer text-white clearfix small z-1 bg-success border-top border-light" href="<?php echo site_url('admin/products/add'); ?>">
								<span class="float-left">Add New Product</span>
								<span class="float-right"><i class="fas fa-angle-right"></i></span>
							</a>
						</div>
					</div>

					<div class="col-xl-3 col-sm-6 mb-3">
						<div class="card text-white bg-danger o-hidden h-100 shadow-sm">
							<div class="card-body">
								<div class="d-flex justify-content-between align-items-center">
									<div>
										<div class="text-uppercase small font-weight-bold">Registered Users</div>
										<div class="h4 mb-0 font-weight-bold"><?php echo (int) $total_users; ?> Akun</div>
									</div>
									<i class="fas fa-fw fa-users fa-2x text-white-50"></i>
								</div>
							</div>
							<a class="card-footer text-white clearfix small z-1 bg-danger border-top border-light" href="#" data-toggle="modal" data-target="#userProfileModal">
								<span class="float-left">View Account</span>
								<span class="float-right"><i class="fas fa-angle-right"></i></span>
							</a>
						</div>
					</div>
				</div>

				<!-- Area Chart Example -->
				<div class="card shadow-sm mb-4">
					<div class="card-header py-3">
						<h6 class="m-0 font-weight-bold text-success"><i class="fas fa-chart-area mr-1"></i> Area Chart Example</h6>
					</div>
					<div class="card-body">
						<div class="chart-area" style="height: 280px;">
							<canvas id="myAreaChart"></canvas>
						</div>
					</div>
					<div class="card-footer small text-muted">Ringkasan Penjualan Bulanan</div>
				</div>

				<!-- DataTables Example -->
				<div class="card shadow-sm mb-4">
					<div class="card-header py-3 d-flex justify-content-between align-items-center">
						<h6 class="m-0 font-weight-bold text-success"><i class="fas fa-table mr-1"></i> Data Table Example - Products</h6>
						<a href="<?php echo site_url('admin/products/add'); ?>" class="btn btn-sm btn-success">
							<i class="fas fa-plus"></i> Add Product
						</a>
					</div>
					<div class="card-body">
						<div class="table-responsive">
							<table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
								<thead>
									<tr>
										<th>Name</th>
										<th>Price</th>
										<th>Photo</th>
										<th>Description</th>
									</tr>
								</thead>
								<tbody>
									<?php foreach ($products as $product): ?>
									<tr>
										<td><?php echo html_escape($product->name); ?></td>
										<td>Rp <?php echo number_format((int) $product->price, 0, ',', '.'); ?></td>
										<td>
											<img src="<?php echo base_url('upload/product/' . $product->image); ?>" width="56" alt="<?php echo html_escape($product->name); ?>" class="rounded">
										</td>
										<td><?php echo html_escape(substr($product->description, 0, 120)); ?></td>
									</tr>
									<?php endforeach; ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>

			</div>
		</div>

		<?php $this->load->view('admin/_partials/footer.php'); ?>
	</div>

</div>

<?php $this->load->view('admin/_partials/scrolltop.php'); ?>
<?php $this->load->view('admin/_partials/modal.php'); ?>
<?php $this->load->view('admin/_partials/js.php'); ?>
<script src="<?php echo base_url('assets/js/demo/chart-area-demo.js'); ?>"></script>
</body>
</html>
