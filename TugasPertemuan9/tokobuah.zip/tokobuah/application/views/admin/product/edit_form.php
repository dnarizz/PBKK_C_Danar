<!DOCTYPE html>
<html lang="id">
<head>
	<?php $this->load->view('admin/_partials/head.php'); ?>
</head>
<body id="page-top">

<?php $this->load->view('admin/_partials/navbar.php'); ?>

<div id="wrapper">

	<?php $this->load->view('admin/_partials/sidebar.php'); ?>

	<div id="content-wrapper" class="d-flex flex-column">
		<div id="content" class="pt-4">
			<div class="container-fluid">

				<?php $this->load->view('admin/_partials/breadcrumb.php'); ?>

				<?php if ($this->session->flashdata('success')): ?>
					<div class="alert alert-success alert-dismissible fade show" role="alert">
						<?php echo html_escape($this->session->flashdata('success')); ?>
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
				<?php endif; ?>

				<div class="card shadow-sm mb-4">
					<div class="card-header">
						<a href="<?php echo site_url('admin/products'); ?>">
							<i class="fas fa-arrow-left"></i> Back
						</a>
					</div>
					<div class="card-body">
						<form action="<?php echo site_url('admin/products/edit/' . $product->product_id); ?>" method="post" enctype="multipart/form-data">
							<input type="hidden" name="id" value="<?php echo html_escape($product->product_id); ?>" />
							<input type="hidden" name="old_image" value="<?php echo html_escape($product->image); ?>" />

							<div class="form-group">
								<label for="name">Name*</label>
								<input class="form-control <?php echo form_error('name') ? 'is-invalid' : ''; ?>" type="text" name="name" id="name" placeholder="Product name" value="<?php echo html_escape($product->name); ?>" />
								<div class="invalid-feedback">
									<?php echo form_error('name'); ?>
								</div>
							</div>

							<div class="form-group">
								<label for="price">Price*</label>
								<input class="form-control <?php echo form_error('price') ? 'is-invalid' : ''; ?>" type="number" name="price" id="price" min="0" placeholder="Product price" value="<?php echo html_escape($product->price); ?>" />
								<div class="invalid-feedback">
									<?php echo form_error('price'); ?>
								</div>
							</div>

							<div class="form-group">
								<label for="image">Photo</label>
								<div class="mb-2">
									<img src="<?php echo base_url('upload/product/' . $product->image); ?>" width="96" alt="<?php echo html_escape($product->name); ?>" class="img-thumbnail" />
								</div>
								<input class="form-control-file" type="file" name="image" id="image" accept="image/*" />
								<small class="form-text text-muted">Kosongkan jika tidak ingin mengganti foto produk.</small>
							</div>

							<div class="form-group">
								<label for="description">Description*</label>
								<textarea class="form-control <?php echo form_error('description') ? 'is-invalid' : ''; ?>" name="description" id="description" rows="4" placeholder="Product description..."><?php echo html_escape($product->description); ?></textarea>
								<div class="invalid-feedback">
									<?php echo form_error('description'); ?>
								</div>
							</div>

							<input class="btn btn-success" type="submit" name="btn" value="Save" />
						</form>
					</div>
					<div class="card-footer small text-muted">
						* required fields
					</div>
				</div>

			</div>
		</div>

		<?php $this->load->view('admin/_partials/footer.php'); ?>
	</div>

</div>

<?php $this->load->view('admin/_partials/scrolltop.php'); ?>
<?php $this->load->view('admin/_partials/modal.php'); ?>
<?php $this->load->view('admin/_partials/js.php'); ?>
</body>
</html>
