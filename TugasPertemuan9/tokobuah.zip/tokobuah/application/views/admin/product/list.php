<!DOCTYPE html>
<html lang="id">
<head>
	<?php $this->load->view('admin/_partials/head.php'); ?>
</head>
<body id="page-top">

<?php $this->load->view('admin/_partials/navbar.php'); ?>

<div id="wrapper">

	<?php $this->load->view('admin/_partials/sidebar.php'); ?>

	<div id="content-wrapper" class="d-flex flex-column">
		<div id="content" class="pt-4">
			<div class="container-fluid">

				<?php $this->load->view('admin/_partials/breadcrumb.php'); ?>

				<?php if ($this->session->flashdata('success')): ?>
					<div class="alert alert-success alert-dismissible fade show" role="alert">
						<?php echo html_escape($this->session->flashdata('success')); ?>
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
				<?php endif; ?>

				<!-- DataTables -->
				<div class="card shadow-sm mb-4">
					<div class="card-header py-3">
						<a href="<?php echo site_url('admin/products/add'); ?>" class="btn btn-sm btn-success">
							<i class="fas fa-plus"></i> Add New
						</a>
					</div>
					<div class="card-body">
						<div class="table-responsive">
							<table class="table table-hover table-bordered" id="dataTable" width="100%" cellspacing="0">
								<thead>
									<tr>
										<th>Name</th>
										<th>Price</th>
										<th>Photo</th>
										<th>Description</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									<?php foreach ($products as $product): ?>
									<tr>
										<td width="150">
											<?php echo html_escape($product->name); ?>
										</td>
										<td>
											Rp <?php echo number_format((int) $product->price, 0, ',', '.'); ?>
										</td>
										<td>
											<img src="<?php echo base_url('upload/product/' . $product->image); ?>" width="64" alt="<?php echo html_escape($product->name); ?>" class="rounded" />
										</td>
										<td class="small">
											<?php echo html_escape(substr($product->description, 0, 120)); ?>
										</td>
										<td width="180">
											<a href="<?php echo site_url('admin/products/edit/' . $product->product_id); ?>" class="btn btn-sm btn-outline-primary">
												<i class="fas fa-edit"></i> Edit
											</a>
											<button type="button" onclick="deleteConfirm('<?php echo site_url('admin/products/delete/' . $product->product_id); ?>')" class="btn btn-sm btn-outline-danger">
												<i class="fas fa-trash"></i> Delete
											</button>
										</td>
									</tr>
									<?php endforeach; ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>

			</div>
		</div>

		<?php $this->load->view('admin/_partials/footer.php'); ?>
	</div>

</div>

<?php $this->load->view('admin/_partials/scrolltop.php'); ?>
<?php $this->load->view('admin/_partials/modal.php'); ?>
<?php $this->load->view('admin/_partials/js.php'); ?>

<script>
function deleteConfirm(url) {
	$('#btn-delete').attr('href', url);
	$('#deleteModal').modal();
}
</script>
</body>
</html>
