<?php $this->load->view('_partials/public_header'); ?>

<div class="row">
	<div class="col-lg-5 mb-4">
		<div class="card shadow-sm h-100">
			<div class="card-header bg-success text-white font-weight-bold">
				<i class="fas fa-address-book mr-2"></i>Informasi Kontak
			</div>
			<div class="card-body">
				<p class="text-muted">
					Halaman ini dipetakan dari route <code>/contact</code> ke method <code>Welcome::contact()</code>.
				</p>
				<ul class="list-unstyled mb-0">
					<li class="mb-3">
						<i class="fas fa-user text-success mr-2"></i>
						<strong>Nama:</strong> <?php echo html_escape($biodata['nama']); ?>
					</li>
					<li class="mb-3">
						<i class="fas fa-university text-success mr-2"></i>
						<strong>Kampus:</strong> <?php echo html_escape($biodata['kampus']); ?>
					</li>
					<li>
						<i class="fas fa-map-marker-alt text-success mr-2"></i>
						<strong>Alamat Toko:</strong> Jl. Teknik Kimia, Sukolilo, Surabaya
					</li>
				</ul>
			</div>
		</div>
	</div>

	<div class="col-lg-7 mb-4">
		<div class="card shadow-sm h-100">
			<div class="card-header bg-white font-weight-bold text-success">
				<i class="fas fa-paper-plane mr-2"></i>Kirim Pesan (Preview Form)
			</div>
			<div class="card-body">
				<form onsubmit="event.preventDefault(); document.getElementById('contactAlert').classList.remove('d-none');">
					<div id="contactAlert" class="alert alert-success d-none" role="alert">
						Terima kasih! Form preview ini berfungsi untuk demonstrasi halaman Contact.
					</div>
					<div class="form-group">
						<label for="contactName">Nama Lengkap</label>
						<input type="text" class="form-control" id="contactName" placeholder="Masukkan nama Anda" required>
					</div>
					<div class="form-group">
						<label for="contactEmail">Alamat Email</label>
						<input type="email" class="form-control" id="contactEmail" placeholder="nama@contoh.com" required>
					</div>
					<div class="form-group">
						<label for="contactMessage">Pesan</label>
						<textarea class="form-control" id="contactMessage" rows="3" placeholder="Tuliskan pesan Anda..." required></textarea>
					</div>
					<button type="submit" class="btn btn-success">
						<i class="fas fa-paper-plane mr-1"></i> Kirim Pesan
					</button>
					<a href="<?php echo site_url('/'); ?>" class="btn btn-outline-secondary ml-2">Kembali</a>
				</form>
			</div>
		</div>
	</div>
</div>

<?php $this->load->view('_partials/public_footer'); ?>
