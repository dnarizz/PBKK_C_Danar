<?php $this->load->view('_partials/public_header'); ?>

<div class="jumbotron bg-white shadow-sm border-left-success">
	<div class="row align-items-center">
		<div class="col-lg-8">
			<span class="badge badge-success mb-2 px-3 py-1">PBKK - Latihan 1 (CodeIgniter 3)</span>
			<h1 class="display-5 font-weight-bold text-dark">Selamat Datang di Toko Buah</h1>
			<p class="lead text-muted mb-3">
				Aplikasi web berbasis CodeIgniter 3 MVC dengan template Bootstrap SB Admin, manajemen produk (CRUD), upload foto, dan autentikasi admin.
			</p>
			<div class="d-flex flex-wrap">
				<a class="btn btn-success mr-2 mb-2" href="<?php echo site_url('admin/login'); ?>">
					<i class="fas fa-tachometer-alt mr-1"></i> Masuk Panel Admin
				</a>
				<a class="btn btn-outline-success mr-2 mb-2" href="<?php echo site_url('about'); ?>">
					<i class="fas fa-info-circle mr-1"></i> Tentang Aplikasi
				</a>
				<a class="btn btn-outline-secondary mb-2" href="<?php echo site_url('contact'); ?>">
					<i class="fas fa-envelope mr-1"></i> Hubungi Kami
				</a>
			</div>
		</div>
		<div class="col-lg-4 text-center mt-4 mt-lg-0">
			<img src="<?php echo base_url('upload/product/default.jpg'); ?>" alt="Tokobuah" class="img-fluid rounded shadow-sm" style="max-height: 190px;">
		</div>
	</div>
</div>

<div class="row">
	<div class="col-lg-7 mb-4">
		<div class="card shadow-sm h-100">
			<div class="card-header bg-success text-white font-weight-bold">
				<i class="fas fa-id-card mr-2"></i>Profil Biodata Mahasiswa (Tahap 2-1)
			</div>
			<div class="card-body">
				<table class="table table-borderless table-sm mb-0">
					<tbody>
						<tr>
							<th style="width: 35%;">Nama</th>
							<td>: <?php echo html_escape($biodata['nama']); ?></td>
						</tr>
						<tr>
							<th>NRP</th>
							<td>: <?php echo html_escape($biodata['nrp']); ?></td>
						</tr>
						<tr>
							<th>Kelas</th>
							<td>: <?php echo html_escape($biodata['kelas']); ?></td>
						</tr>
						<tr>
							<th>Program Studi</th>
							<td>: <?php echo html_escape($biodata['prodi']); ?></td>
						</tr>
						<tr>
							<th>Mata Kuliah</th>
							<td>: <?php echo html_escape($biodata['mata_kuliah']); ?></td>
						</tr>
						<tr>
							<th>Kampus</th>
							<td>: <?php echo html_escape($biodata['kampus']); ?></td>
						</tr>
						<tr>
							<th>Moto</th>
							<td>: <?php echo html_escape($biodata['moto']); ?></td>
						</tr>
					</tbody>
				</table>
			</div>
			<div class="card-footer bg-light small text-muted">
				Latihan 1 PBKK C &mdash; CodeIgniter 3.1.13 MVC
			</div>
		</div>
	</div>

	<div class="col-lg-5 mb-4">
		<div class="card shadow-sm h-100">
			<div class="card-header bg-white font-weight-bold text-success">
				<i class="fas fa-list-check mr-2"></i>Cakupan Fitur Latihan 1
			</div>
			<div class="list-group list-group-flush">
				<a href="<?php echo site_url('/'); ?>" class="list-group-item list-group-item-action">
					<strong>2-1. Instalasi & Welcome Biodata</strong>
					<div class="small text-muted">Halaman utama Welcome dengan profil biodata</div>
				</a>
				<a href="<?php echo site_url('about'); ?>" class="list-group-item list-group-item-action">
					<strong>2-2. Router & Controller</strong>
					<div class="small text-muted">Route <code>/about</code> &amp; <code>/contact</code> ke method controller</div>
				</a>
				<a href="<?php echo site_url('admin'); ?>" class="list-group-item list-group-item-action">
					<strong>2-3 &amp; 2-4. SB Admin &amp; View Partials</strong>
					<div class="small text-muted">Dashboard dengan partial navbar, sidebar, breadcrumb, footer</div>
				</a>
				<a href="<?php echo site_url('admin/products'); ?>" class="list-group-item list-group-item-action">
					<strong>2-5 &amp; 2-6. Model CRUD &amp; File Upload</strong>
					<div class="small text-muted">Kelola data buah &amp; upload gambar produk</div>
				</a>
				<a href="<?php echo site_url('admin/login'); ?>" class="list-group-item list-group-item-action">
					<strong>2-7. Mengatur Akses User</strong>
					<div class="small text-muted">Login Admin dengan proteksi session</div>
				</a>
			</div>
		</div>
	</div>
</div>

<?php $this->load->view('_partials/public_footer'); ?>
