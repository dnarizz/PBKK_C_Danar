-- ============================================================
-- Database: `tokobuah`
-- Latihan 1 PBKK: Pengenalan Framework CodeIgniter 3
-- ============================================================

CREATE DATABASE IF NOT EXISTS `tokobuah` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `tokobuah`;

-- --------------------------------------------------------
-- Struktur dari tabel `products`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `product_id` varchar(64) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT 'default.jpg',
  `description` text NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `products` (`product_id`, `name`, `price`, `image`, `description`) VALUES
('67401a0b10001', 'Manggis', 45000, 'default.jpg', 'Buah manggis segar pilihan dengan rasa manis alami dan kaya antioksidan per kilogram.'),
('67401a0b10002', 'Mangga Harum Manis', 35000, 'default.jpg', 'Mangga harum manis matang pohon, daging buah tebal, manis, dan harum per kilogram.'),
('67401a0b10003', 'Apel Fuji', 42000, 'default.jpg', 'Apel Fuji renyah dan berair dengan tingkat kemanisan tinggi cocok untuk konsumsi harian.'),
('67401a0b10004', 'Jeruk Mandarin', 38000, 'default.jpg', 'Jeruk mandarin segar kaya vitamin C dengan kulit mudah dikupas dan rasa manis menyegarkan.'),
('67401a0b10005', 'Alpukat Mentega', 40000, 'default.jpg', 'Alpukat mentega pulen bertekstur lembut tanpa serat, ideal untuk jus atau salad.');

-- --------------------------------------------------------
-- Struktur dari tabel `users`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL DEFAULT '',
  `role` enum('admin','customer') NOT NULL DEFAULT 'customer',
  `last_login` timestamp NULL DEFAULT NULL,
  `photo` varchar(64) NOT NULL DEFAULT 'user_no_image.jpg',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `uniq_username` (`username`),
  UNIQUE KEY `uniq_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `users` (`user_id`, `username`, `password`, `email`, `full_name`, `phone`, `role`, `last_login`, `photo`, `is_active`) VALUES
(1, 'admin', '$2y$10$YxVHUMRVwVCqFXgEOty1Ze6e/Acv/L34tLLoEijK5g41/Z/yU8iAy', 'admin@tokobuah.test', 'Administrator Tokobuah', '081234567890', 'admin', NULL, 'user_no_image.jpg', 1);
