<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Halaman Utama & Informasi Publik (HOL Praktikum 3 + PRD Bab 10)
$routes->get('/', 'HomeController::index', ['as' => 'home']);
$routes->get('about', 'HomeController::about', ['as' => 'about']);
$routes->get('contact', 'HomeController::contact', ['as' => 'contact']);
$routes->post('contact/send', 'HomeController::sendContact', ['as' => 'contact.send']);

// Katalog, Kategori, dan Detail Produk Publik (PRD Bab 10 + BR-002)
$routes->get('catalog', 'ProductController::catalog', ['as' => 'catalog']);
$routes->get('category/(:segment)', 'ProductController::category/$1', ['as' => 'category.show']);
$routes->get('product/(:segment)', 'ProductController::detail/$1', ['as' => 'product.detail']);

// Keranjang Belanja (Session Cart + Validasi Stok BR-003 & BR-005)
$routes->get('cart', 'CartController::index', ['as' => 'cart']);
$routes->post('cart/add', 'CartController::add', ['as' => 'cart.add']);
$routes->post('cart/update', 'CartController::update', ['as' => 'cart.update']);
$routes->post('cart/remove', 'CartController::remove', ['as' => 'cart.remove']);

// Autentikasi Customer (FR-001 s.d. FR-003)
$routes->get('login', 'AuthController::login', ['as' => 'login']);
$routes->post('login', 'AuthController::attemptLogin', ['as' => 'login.attempt']);
$routes->get('register', 'AuthController::register', ['as' => 'register']);
$routes->post('register', 'AuthController::attemptRegister', ['as' => 'register.attempt']);
$routes->get('logout', 'AuthController::logout', ['as' => 'logout']);
