<?php

namespace App\Controllers;

/**
 * AuthController
 *
 * Mengelola halaman Login (/login), Registrasi Customer (/register),
 * dan Logout (/logout) dengan validasi server-side dan password hashing (FR-001 s.d. FR-003).
 */
class AuthController extends BaseController
{
    /**
     * Daftar akun demonstrasi non-pribadi (hash bcrypt untuk password: shopease123).
     *
     * @return array<string, array<string, string>>
     */
    private function getDemoUsers(): array
    {
        $defaultHash = '$2y$10$PAC7JBBnwyvIIiqmJu53Uu3vGYiJQpA9vcs5x30df9cwP0BGGU0Iu';

        $builtIn = [
            'customer@shopease-demo.local' => [
                'name'          => 'Pelanggan Contoh Satu',
                'email'         => 'customer@shopease-demo.local',
                'role'          => 'customer',
                'password_hash' => $defaultHash,
            ],
            'admin@shopease-demo.local' => [
                'name'          => 'Admin ShopEase Demo',
                'email'         => 'admin@shopease-demo.local',
                'role'          => 'admin',
                'password_hash' => $defaultHash,
            ],
        ];

        $registered = $this->session->get('shopease_registered_users');
        if (is_array($registered)) {
            $builtIn = array_merge($builtIn, $registered);
        }

        return $builtIn;
    }

    /**
     * Halaman Login (GET /login).
     */
    public function login(): string
    {
        $data = array_merge($this->sharedViewData('login'), [
            'title' => 'Masuk Akun – ShopEase',
        ]);

        return view('auth/login', $data);
    }

    /**
     * Memproses autentikasi pengguna (POST /login).
     */
    public function attemptLogin()
    {
        $rules = [
            'email'    => 'required|valid_email',
            'password' => 'required|min_length[6]',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()
                ->withInput()
                ->with('errors', $this->validator->getErrors());
        }

        $email    = mb_strtolower(trim((string) $this->request->getPost('email')));
        $password = (string) $this->request->getPost('password');

        $users = $this->getDemoUsers();
        $user  = $users[$email] ?? null;

        // Pesan kesalahan generik sesuai PRD Bab 13 agar tidak membocorkan status email.
        if ($user === null || ! password_verify($password, $user['password_hash'])) {
            return redirect()->back()
                ->withInput()
                ->with('error', 'Email atau kata sandi tidak valid.');
        }

        $this->session->regenerate();
        $this->session->set('shopease_user', [
            'name'  => $user['name'],
            'email' => $user['email'],
            'role'  => $user['role'],
        ]);

        return redirect()->to(route_to('home'))
            ->with('success', 'Selamat datang kembali, ' . $user['name'] . '!');
    }

    /**
     * Halaman Registrasi Customer (GET /register).
     */
    public function register(): string
    {
        $data = array_merge($this->sharedViewData('register'), [
            'title' => 'Daftar Akun Customer – ShopEase',
        ]);

        return view('auth/register', $data);
    }

    /**
     * Memproses pendaftaran akun customer baru (POST /register).
     */
    public function attemptRegister()
    {
        $rules = [
            'name'             => 'required|min_length[3]|max_length[100]',
            'email'            => 'required|valid_email|max_length[120]',
            'password'         => 'required|min_length[6]',
            'password_confirm' => 'required|matches[password]',
        ];

        $messages = [
            'name' => [
                'required'   => 'Nama lengkap wajib diisi.',
                'min_length' => 'Nama lengkap minimal 3 karakter.',
            ],
            'email' => [
                'required'    => 'Email wajib diisi.',
                'valid_email' => 'Format email tidak valid.',
            ],
            'password' => [
                'required'   => 'Kata sandi wajib diisi.',
                'min_length' => 'Kata sandi minimal 6 karakter.',
            ],
            'password_confirm' => [
                'required' => 'Konfirmasi kata sandi wajib diisi.',
                'matches'  => 'Konfirmasi kata sandi tidak cocok.',
            ],
        ];

        if (! $this->validate($rules, $messages)) {
            return redirect()->back()
                ->withInput()
                ->with('errors', $this->validator->getErrors());
        }

        $name     = trim((string) $this->request->getPost('name'));
        $email    = mb_strtolower(trim((string) $this->request->getPost('email')));
        $password = (string) $this->request->getPost('password');

        $users = $this->getDemoUsers();
        if (isset($users[$email])) {
            return redirect()->back()
                ->withInput()
                ->with('error', 'Alamat email sudah terdaftar. Silakan gunakan email lain.');
        }

        $registered         = $this->session->get('shopease_registered_users') ?? [];
        $registered[$email] = [
            'name'          => $name,
            'email'         => $email,
            'role'          => 'customer',
            'password_hash' => password_hash($password, PASSWORD_DEFAULT),
        ];
        $this->session->set('shopease_registered_users', $registered);

        return redirect()->to(route_to('login'))
            ->with('success', 'Pendaftaran akun customer berhasil! Silakan masuk menggunakan email Anda.');
    }

    /**
     * Mengakhiri session pengguna (GET /logout).
     */
    public function logout()
    {
        $this->session->remove('shopease_user');
        $this->session->regenerate();

        return redirect()->to(route_to('home'))
            ->with('success', 'Anda telah keluar dari akun ShopEase.');
    }
}
