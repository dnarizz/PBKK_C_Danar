<?php

namespace App\Controllers;

use App\Libraries\StoreCatalog;
use CodeIgniter\Controller;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;

/**
 * BaseController
 *
 * Menyediakan helper, session, serta data navigasi bersama (kategori, jumlah keranjang,
 * dan status akun) untuk seluruh controller frontend ShopEase.
 */
abstract class BaseController extends Controller
{
    /**
     * @var list<string>
     */
    protected $helpers = ['url', 'form'];

    protected StoreCatalog $catalog;

    /**
     * @var \CodeIgniter\Session\Session
     */
    protected $session;

    /**
     * @return void
     */
    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        parent::initController($request, $response, $logger);

        $this->session = service('session');
        $this->catalog = new StoreCatalog();
    }

    /**
     * Data bersama untuk layout utama, navbar, dan footer.
     *
     * @return array<string, mixed>
     */
    protected function sharedViewData(string $activeNav = ''): array
    {
        $cart = $this->session->get('shopease_cart');
        $cartCount = 0;
        if (is_array($cart)) {
            foreach ($cart as $qty) {
                $cartCount += max(0, (int) $qty);
            }
        }

        return [
            'categories'  => $this->catalog->getCategoriesWithCount(),
            'cartCount'   => $cartCount,
            'currentUser' => $this->session->get('shopease_user'),
            'activeNav'   => $activeNav,
            'searchQuery' => (string) ($this->request->getGet('q') ?? ''),
        ];
    }
}
