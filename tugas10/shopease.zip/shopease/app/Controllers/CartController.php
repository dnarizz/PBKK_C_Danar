<?php

namespace App\Controllers;

/**
 * CartController
 *
 * Mengelola keranjang belanja berbasis session dengan validasi produk aktif (BR-002),
 * batas stok (BR-003), dan perhitungan ulang subtotal & total di sisi server (BR-005).
 */
class CartController extends BaseController
{
    /**
     * Menampilkan isi keranjang belanja (GET /cart).
     */
    public function index(): string
    {
        $sessionCart = $this->session->get('shopease_cart');
        $items       = [];
        $subtotal    = 0;

        if (is_array($sessionCart)) {
            foreach ($sessionCart as $productId => $qty) {
                $product = $this->catalog->getProductById((int) $productId);
                $qtyInt  = (int) $qty;
                if ($product === null || $qtyInt < 1) {
                    continue;
                }

                $qtyValid = min($qtyInt, (int) $product['stock']);
                $lineTotal = (int) $product['price'] * $qtyValid;
                $subtotal += $lineTotal;

                $items[] = [
                    'product'    => $product,
                    'quantity'   => $qtyValid,
                    'line_total' => $lineTotal,
                ];
            }
        }

        $shippingEstimate = $subtotal > 0 ? 15000 : 0;

        $data = array_merge($this->sharedViewData('cart'), [
            'title'            => 'Keranjang Belanja – ShopEase',
            'items'            => $items,
            'subtotal'         => $subtotal,
            'shippingEstimate' => $shippingEstimate,
            'grandTotal'       => $subtotal + $shippingEstimate,
        ]);

        return view('frontend/cart', $data);
    }

    /**
     * Menambahkan produk aktif ke keranjang dengan validasi stok (POST /cart/add).
     */
    public function add()
    {
        $productId = (int) $this->request->getPost('product_id');
        $quantity  = (int) ($this->request->getPost('quantity') ?? 1);

        if ($quantity < 1) {
            return redirect()->back()->with('error', 'Jumlah produk minimal adalah 1.');
        }

        $product = $this->catalog->getProductById($productId);
        if ($product === null) {
            return redirect()->back()->with('error', 'Produk tidak ditemukan atau sedang tidak aktif.');
        }

        $cart        = $this->session->get('shopease_cart') ?? [];
        $currentQty  = (int) ($cart[$productId] ?? 0);
        $targetQty   = $currentQty + $quantity;

        if ($targetQty > (int) $product['stock']) {
            return redirect()->back()->with(
                'error',
                'Stok tidak mencukupi. Sisa stok tersedia untuk "' . $product['name'] . '" adalah ' . $product['stock'] . ' unit.'
            );
        }

        $cart[$productId] = $targetQty;
        $this->session->set('shopease_cart', $cart);

        return redirect()->to(route_to('cart'))
            ->with('success', '"' . $product['name'] . '" berhasil ditambahkan ke keranjang.');
    }

    /**
     * Memperbarui jumlah item di keranjang (POST /cart/update).
     */
    public function update()
    {
        $productId = (int) $this->request->getPost('product_id');
        $quantity  = (int) $this->request->getPost('quantity');

        $cart = $this->session->get('shopease_cart') ?? [];
        if (! isset($cart[$productId])) {
            return redirect()->to(route_to('cart'))->with('error', 'Item tidak ditemukan di keranjang.');
        }

        if ($quantity <= 0) {
            unset($cart[$productId]);
            $this->session->set('shopease_cart', $cart);
            return redirect()->to(route_to('cart'))->with('success', 'Item dihapus dari keranjang.');
        }

        $product = $this->catalog->getProductById($productId);
        if ($product === null) {
            unset($cart[$productId]);
            $this->session->set('shopease_cart', $cart);
            return redirect()->to(route_to('cart'))->with('error', 'Produk sudah tidak aktif.');
        }

        if ($quantity > (int) $product['stock']) {
            return redirect()->to(route_to('cart'))->with(
                'error',
                'Jumlah melebihi stok tersedia (' . $product['stock'] . ' unit).'
            );
        }

        $cart[$productId] = $quantity;
        $this->session->set('shopease_cart', $cart);

        return redirect()->to(route_to('cart'))->with('success', 'Kuantitas keranjang diperbarui.');
    }

    /**
     * Menghapus item dari keranjang (POST /cart/remove).
     */
    public function remove()
    {
        $productId = (int) $this->request->getPost('product_id');
        $cart      = $this->session->get('shopease_cart') ?? [];

        if (isset($cart[$productId])) {
            unset($cart[$productId]);
            $this->session->set('shopease_cart', $cart);
        }

        return redirect()->to(route_to('cart'))->with('success', 'Produk dihapus dari keranjang belanja.');
    }
}
