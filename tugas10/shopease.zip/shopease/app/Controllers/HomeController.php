<?php

namespace App\Controllers;

/**
 * HomeController
 *
 * Mengatur halaman publik utama ShopEase: Landing Page (/), Tentang (/about),
 * dan Kontak (/contact) sesuai HOL Praktikum 3 & PRD Bab 10.
 */
class HomeController extends BaseController
{
    /**
     * Halaman Landing Page ShopEase (GET /).
     */
    public function index(): string
    {
        $data = array_merge($this->sharedViewData('home'), [
            'title'            => 'ShopEase – Online Store | Belanja Online Mudah, Aman & Terkurasi',
            'metaDescription'  => 'Landing page aplikasi toko online ShopEase berbasis CodeIgniter 4: jelajahi kategori pilihan, produk unggulan, dan alur belanja aman.',
            'featuredProducts' => $this->catalog->getFeaturedProducts(8),
            'storeStats'       => $this->catalog->getStoreStats(),
            'testimonials'     => $this->catalog->getTestimonials(),
        ]);

        return view('frontend/home', $data);
    }

    /**
     * Halaman Tentang ShopEase (GET /about).
     */
    public function about(): string
    {
        $data = array_merge($this->sharedViewData('about'), [
            'title'      => 'Tentang ShopEase – Online Store',
            'storeStats' => $this->catalog->getStoreStats(),
            'objectives' => [
                'Menyediakan katalog produk terpusat dengan informasi harga dan stok yang konsisten.',
                'Menghadirkan alur belanja terstruktur mulai dari pencarian produk hingga checkout aman.',
                'Memisahkan hak akses Customer, Administrator, dan Operator Toko secara jelas.',
                'Menerapkan arsitektur MVC CodeIgniter 4, validasi server-side, CSRF, dan escaping output.',
            ],
            'actors' => [
                [
                    'role'  => 'Customer',
                    'icon'  => 'bi-person-check',
                    'badge' => 'primary',
                    'desc'  => 'Mencari produk, melihat detail dan ketersediaan stok, mengelola keranjang belanja, melakukan checkout, mengunggah bukti pembayaran, serta memantau status pesanan.',
                ],
                [
                    'role'  => 'Administrator',
                    'icon'  => 'bi-shield-check',
                    'badge' => 'warning',
                    'desc'  => 'Mengelola kategori, produk, harga, gambar, stok, memverifikasi bukti pembayaran manual, serta memantau ringkasan laporan penjualan pada dashboard.',
                ],
                [
                    'role'  => 'Operator Toko',
                    'icon'  => 'bi-box-seam',
                    'badge' => 'success',
                    'desc'  => 'Menyiapkan barang pesanan, memperbarui status pemrosesan, serta mengisi data kurir dan nomor resi pengiriman sesuai kewenangan.',
                ],
            ],
        ]);

        return view('frontend/about', $data);
    }

    /**
     * Halaman Kontak & Bantuan ShopEase (GET /contact).
     */
    public function contact(): string
    {
        $data = array_merge($this->sharedViewData('contact'), [
            'title' => 'Hubungi Kami – ShopEase Online Store',
            'faqs'  => [
                [
                    'q' => 'Bagaimana cara memastikan ketersediaan stok produk sebelum membeli?',
                    'a' => 'Setiap kartu dan halaman detail produk menampilkan jumlah stok aktif secara langsung dan divalidasi ulang di server saat dimasukkan ke keranjang.',
                ],
                [
                    'q' => 'Metode pembayaran apa yang didukung pada versi pembelajaran ini?',
                    'a' => 'ShopEase mendukung transfer manual dalam mata uang Rupiah (IDR) dengan unggah bukti pembayaran serta verifikasi oleh Administrator.',
                ],
                [
                    'q' => 'Apakah saya bisa melacak status pesanan setelah checkout?',
                    'a' => 'Ya, status pembayaran dan status pemenuhan pesanan (pending_payment hingga completed) dipantau terpisah secara transparan.',
                ],
            ],
        ]);

        return view('frontend/contact', $data);
    }

    /**
     * Memproses pesan dari formulir halaman Kontak (POST /contact/send).
     */
    public function sendContact()
    {
        $rules = [
            'name'    => 'required|min_length[3]|max_length[100]',
            'email'   => 'required|valid_email|max_length[120]',
            'subject' => 'required|min_length[3]|max_length[120]',
            'message' => 'required|min_length[10]|max_length[1000]',
        ];

        $messages = [
            'name' => [
                'required'   => 'Nama lengkap wajib diisi.',
                'min_length' => 'Nama lengkap minimal 3 karakter.',
            ],
            'email' => [
                'required'    => 'Alamat email wajib diisi.',
                'valid_email' => 'Format alamat email tidak valid.',
            ],
            'subject' => [
                'required'   => 'Subjek pesan wajib diisi.',
                'min_length' => 'Subjek pesan minimal 3 karakter.',
            ],
            'message' => [
                'required'   => 'Isi pesan wajib diisi.',
                'min_length' => 'Pesan minimal terdiri dari 10 karakter.',
            ],
        ];

        if (! $this->validate($rules, $messages)) {
            return redirect()->back()
                ->withInput()
                ->with('errors', $this->validator->getErrors());
        }

        $senderName = (string) $this->request->getPost('name');

        return redirect()->to(route_to('contact'))
            ->with('success', 'Terima kasih, ' . $senderName . '! Pesan Anda telah diterima dan akan ditindaklanjuti oleh tim layanan ShopEase.');
    }
}
