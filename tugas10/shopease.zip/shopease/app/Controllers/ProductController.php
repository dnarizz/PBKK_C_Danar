<?php

namespace App\Controllers;

use CodeIgniter\Exceptions\PageNotFoundException;

/**
 * ProductController
 *
 * Mengelola halaman katalog produk (/catalog), filter kategori (/category/{slug}),
 * dan detail produk (/product/{slug}) dengan penegakan aturan BR-002 (produk nonaktif disembunyikan).
 */
class ProductController extends BaseController
{
    /**
     * Daftar katalog produk aktif dengan pencarian, filter kategori, dan pengurutan (GET /catalog).
     */
    public function catalog(): string
    {
        $search       = trim((string) ($this->request->getGet('q') ?? ''));
        $categorySlug = trim((string) ($this->request->getGet('category') ?? ''));
        $sort         = trim((string) ($this->request->getGet('sort') ?? 'featured'));

        $allowedSorts = ['featured', 'price_asc', 'price_desc', 'name_asc', 'bestseller'];
        if (! in_array($sort, $allowedSorts, true)) {
            $sort = 'featured';
        }

        $activeCategory = $categorySlug !== '' ? $this->catalog->getCategoryBySlug($categorySlug) : null;
        $products       = $this->catalog->getActiveProducts($search, $categorySlug !== '' ? $categorySlug : null, $sort);

        $data = array_merge($this->sharedViewData('catalog'), [
            'title'          => $activeCategory ? 'Kategori ' . $activeCategory['name'] . ' – ShopEase' : 'Katalog Produk – ShopEase',
            'products'       => $products,
            'activeCategory' => $activeCategory,
            'selectedSlug'   => $categorySlug,
            'sort'           => $sort,
            'searchQuery'    => $search,
        ]);

        return view('frontend/catalog', $data);
    }

    /**
     * Halaman katalog terfilter berdasarkan segment slug kategori (GET /category/{slug}).
     */
    public function category(string $slug): string
    {
        $category = $this->catalog->getCategoryBySlug($slug);
        if ($category === null) {
            throw PageNotFoundException::forPageNotFound('Kategori tidak ditemukan.');
        }

        $search = trim((string) ($this->request->getGet('q') ?? ''));
        $sort   = trim((string) ($this->request->getGet('sort') ?? 'featured'));

        $allowedSorts = ['featured', 'price_asc', 'price_desc', 'name_asc', 'bestseller'];
        if (! in_array($sort, $allowedSorts, true)) {
            $sort = 'featured';
        }

        $products = $this->catalog->getActiveProducts($search, $slug, $sort);

        $data = array_merge($this->sharedViewData('catalog'), [
            'title'          => 'Kategori ' . $category['name'] . ' – ShopEase',
            'products'       => $products,
            'activeCategory' => $category,
            'selectedSlug'   => $slug,
            'sort'           => $sort,
            'searchQuery'    => $search,
        ]);

        return view('frontend/catalog', $data);
    }

    /**
     * Halaman detail produk aktif (GET /product/{slug}).
     * Produk nonaktif (BR-002) atau slug tidak dikenal otomatis mengembalikan 404.
     */
    public function detail(string $slug): string
    {
        $product = $this->catalog->getProductBySlug($slug);
        if ($product === null) {
            throw PageNotFoundException::forPageNotFound('Produk tidak tersedia atau sedang dinonaktifkan.');
        }

        $data = array_merge($this->sharedViewData('catalog'), [
            'title'           => $product['name'] . ' – ShopEase',
            'product'         => $product,
            'relatedProducts' => $this->catalog->getRelatedProducts($product, 4),
        ]);

        return view('frontend/product_detail', $data);
    }
}
