<?php

namespace App\Libraries;

/**
 * StoreCatalog
 *
 * Sumber data katalog terpusat untuk lapisan presentasi ShopEase (PRD Bab 10-11 & HOL Praktikum 3).
 * Menyediakan data kategori, produk aktif/nonaktif (uji aturan bisnis BR-002), statistik toko,
 * dan testimoni pelanggan agar halaman publik berjalan konsisten dan siap dihubungkan ke MySQL.
 */
class StoreCatalog
{
    /**
     * Daftar kategori resmi toko (PRD Tabel `categories`).
     *
     * @return list<array<string, mixed>>
     */
    public function getAllCategories(): array
    {
        return [
            [
                'id'          => 1,
                'name'        => 'Elektronik',
                'slug'        => 'elektronik',
                'icon'        => 'bi-headphones',
                'description' => 'Audio nirkabel, perangkat komputasi, dan gadget pintar harian.',
                'accent'      => '#2563EB',
                'is_active'   => true,
            ],
            [
                'id'          => 2,
                'name'        => 'Fashion',
                'slug'        => 'fashion',
                'icon'        => 'bi-bag-heart',
                'description' => 'Sepatu kasual, outerwear denim, dan koleksi gaya modern.',
                'accent'      => '#F97316',
                'is_active'   => true,
            ],
            [
                'id'          => 3,
                'name'        => 'Aksesoris',
                'slug'        => 'aksesoris',
                'icon'        => 'bi-backpack2',
                'description' => 'Tas laptop anti air dan perlengkapan mobilitas harian.',
                'accent'      => '#0EA5E9',
                'is_active'   => true,
            ],
            [
                'id'          => 4,
                'name'        => 'Rumah Tangga',
                'slug'        => 'rumah-tangga',
                'icon'        => 'bi-lamp',
                'description' => 'Lampu meja minimalis dan perlengkapan ruang kerja nyaman.',
                'accent'      => '#10B981',
                'is_active'   => true,
            ],
            [
                'id'          => 5,
                'name'        => 'Olahraga & Hobi',
                'slug'        => 'olahraga',
                'icon'        => 'bi-bicycle',
                'description' => 'Botol hidrasi sport dan peralatan pendukung aktivitas aktif.',
                'accent'      => '#8B5CF6',
                'is_active'   => true,
            ],
            [
                'id'          => 6,
                'name'        => 'Perawatan & Kecantikan',
                'slug'        => 'kecantikan',
                'icon'        => 'bi-droplet-half',
                'description' => 'Perawatan kulit harian dengan formula ringan dan teruji.',
                'accent'      => '#EC4899',
                'is_active'   => true,
            ],
        ];
    }

    /**
     * Daftar seluruh produk (10 produk aktif + 1 produk nonaktif untuk pengujian BR-002).
     *
     * @return list<array<string, mixed>>
     */
    private function getRawProducts(): array
    {
        return [
            [
                'id'             => 1,
                'category_id'    => 1,
                'category_slug'  => 'elektronik',
                'category_name'  => 'Elektronik',
                'name'           => 'Wireless Headphone ANC Pro',
                'slug'           => 'wireless-headphone-pro',
                'short_desc'     => 'Bluetooth 5.3, Active Noise Cancelling adaptif, baterai 38 jam.',
                'description'    => 'Nikmati audio jernih tanpa gangguan bising sekitar dengan driver dinamis 40mm, bantalan telinga memory foam yang lembut, serta pengisian cepat USB-C untuk pemakaian kuliah, kerja, dan perjalanan.',
                'price'          => 299000,
                'original_price' => 379000,
                'stock'          => 20,
                'image'          => 'wireless-headphone.jpg',
                'status'         => 'active',
                'is_featured'    => true,
                'badge'          => 'Terlaris',
                'rating'         => 4.9,
                'sold_count'     => 148,
                'specs'          => [
                    'Konektivitas' => 'Bluetooth 5.3 + Kabel AUX 3.5mm',
                    'Daya Baterai' => 'Hingga 38 jam pemutaran aktif',
                    'Port Isi Ulang' => 'USB Type-C Fast Charging',
                    'Garansi'      => '1 Tahun Garansi Resmi Toko',
                ],
            ],
            [
                'id'             => 2,
                'category_id'    => 2,
                'category_slug'  => 'fashion',
                'category_name'  => 'Fashion',
                'name'           => 'Sneakers Casual Urban',
                'slug'           => 'sneakers-casual-urban',
                'short_desc'     => 'Sol phylon ringan dan upper mesh breathable untuk aktivitas harian.',
                'description'    => 'Sneakers kasual serbaguna dengan desain bersih yang cocok dipadukan dengan gaya kampus maupun semi-formal. Dilengkapi insole empuk anti-lelah dan outsole karet berdaya cengkeram tinggi.',
                'price'          => 350000,
                'original_price' => 420000,
                'stock'          => 15,
                'image'          => 'sneakers-casual.svg',
                'status'         => 'active',
                'is_featured'    => true,
                'badge'          => 'Hemat 17%',
                'rating'         => 4.8,
                'sold_count'     => 112,
                'specs'          => [
                    'Material Upper' => 'Engineered Mesh + Kulit Sintetis',
                    'Material Sol'   => 'Phylon Ringan & Karet Anti-Selip',
                    'Ukuran Tersedia'=> '39 – 44 (EU)',
                    'Bobot Sepatu'   => '± 290 gram per pasang',
                ],
            ],
            [
                'id'             => 3,
                'category_id'    => 1,
                'category_slug'  => 'elektronik',
                'category_name'  => 'Elektronik',
                'name'           => 'Smart Watch Fit Series',
                'slug'           => 'smart-watch-fit-series',
                'short_desc'     => 'Layar AMOLED cerah, sensor detak jantung 24 jam, tahan air 5ATM.',
                'description'    => 'Pantau kebugaran harian, kualitas tidur, notifikasi pesan, dan lebih dari 50 mode olahraga langsung dari pergelangan tangan dengan bodi aluminium ringan dan baterai tahan hingga 10 hari.',
                'price'          => 450000,
                'original_price' => 549000,
                'stock'          => 12,
                'image'          => 'smart-watch.svg',
                'status'         => 'active',
                'is_featured'    => true,
                'badge'          => 'Favorit',
                'rating'         => 4.9,
                'sold_count'     => 96,
                'specs'          => [
                    'Layar'        => '1.78" AMOLED Touch Display',
                    'Ketahanan Air'=> '5ATM (Tahan Percikan & Hujan)',
                    'Sensor'       => 'Detak Jantung, SpO2, Akselerometer',
                    'Baterai'      => 'Hingga 10 hari penggunaan normal',
                ],
            ],
            [
                'id'             => 4,
                'category_id'    => 1,
                'category_slug'  => 'elektronik',
                'category_name'  => 'Elektronik',
                'name'           => 'Keyboard Mekanikal Wireless 75%',
                'slug'           => 'keyboard-mekanikal-75',
                'short_desc'     => 'Layout 84 tombol compact dengan knob putar & koneksi tri-mode.',
                'description'    => 'Dirancang untuk produktivitas developer dan mahasiswa, keyboard mekanikal 75% ini mendukung koneksi Bluetooth 5.0, dongle 2.4GHz, dan kabel USB-C dengan switch linear yang halus dan senyap.',
                'price'          => 649000,
                'original_price' => 750000,
                'stock'          => 18,
                'image'          => 'mechanical-keyboard.svg',
                'status'         => 'active',
                'is_featured'    => true,
                'badge'          => 'Baru',
                'rating'         => 4.9,
                'sold_count'     => 84,
                'specs'          => [
                    'Layout'       => '75% Compact (84 Tombol + Rotary Knob)',
                    'Konektivitas' => 'Tri-Mode (USB-C / 2.4GHz / Bluetooth)',
                    'Fitur Socket' => 'Hot-Swappable 5-Pin',
                    'Kompatibilitas'=> 'Windows, macOS, dan Linux',
                ],
            ],
            [
                'id'             => 5,
                'category_id'    => 3,
                'category_slug'  => 'aksesoris',
                'category_name'  => 'Aksesoris',
                'name'           => 'Ransel Laptop Anti Air 15.6"',
                'slug'           => 'ransel-laptop-anti-air',
                'short_desc'     => 'Kompartemen laptop empuk 15.6", bahan tahan cipratan air, port USB.',
                'description'    => 'Tas ransel minimalis berbahan poliester oxford berlapis pelindung air yang menjaga laptop, tablet, dan catatan kuliah tetap aman serta rapi dalam banyak kompartemen organizer.',
                'price'          => 275000,
                'original_price' => 330000,
                'stock'          => 25,
                'image'          => 'laptop-backpack.svg',
                'status'         => 'active',
                'is_featured'    => true,
                'badge'          => 'Populer',
                'rating'         => 4.8,
                'sold_count'     => 134,
                'specs'          => [
                    'Kapasitas'    => '22 Liter (Muat Laptop s.d. 15.6")',
                    'Material'     => 'Water-Repellent Oxford Fabric',
                    'Fitur Tambahan'=> 'Slot Koper & Port USB Eksternal',
                    'Dimensi'      => '44 × 30 × 14 cm',
                ],
            ],
            [
                'id'             => 6,
                'category_id'    => 4,
                'category_slug'  => 'rumah-tangga',
                'category_name'  => 'Rumah Tangga',
                'name'           => 'Tumbler Vacuum Stainless 500ml',
                'slug'           => 'tumbler-vacuum-500ml',
                'short_desc'     => 'Stainless steel 304 dinding ganda, tahan panas 12 jam & dingin 24 jam.',
                'description'    => 'Jaga suhu minuman favorit lebih lama saat belajar atau bekerja. Tutup rapat anti-bocor dengan lapisan powder-coating matte yang nyaman digenggam dan bebas kondensasi.',
                'price'          => 129000,
                'original_price' => 159000,
                'stock'          => 40,
                'image'          => 'coffee-tumbler.svg',
                'status'         => 'active',
                'is_featured'    => true,
                'badge'          => 'Hemat',
                'rating'         => 4.7,
                'sold_count'     => 210,
                'specs'          => [
                    'Kapasitas'    => '500 ml',
                    'Material'     => 'Food-Grade Stainless Steel 304',
                    'Insulasi'     => 'Panas 12 jam / Dingin 24 jam',
                    'Bebas BPA'    => 'Ya (BPA-Free Lid)',
                ],
            ],
            [
                'id'             => 7,
                'category_id'    => 4,
                'category_slug'  => 'rumah-tangga',
                'category_name'  => 'Rumah Tangga',
                'name'           => 'Lampu Meja LED Minimalis Touch',
                'slug'           => 'lampu-meja-led-touch',
                'short_desc'     => '3 mode suhu warna cahaya, kontrol sentuh, ramah mata tanpa kedip.',
                'description'    => 'Penerangan meja kerja modern dengan teknologi diffused LED anti-silau dan peredup sentuh 3 tingkat kecerahan. Cocok untuk membaca buku, menyusun kode, dan bekerja hingga malam.',
                'price'          => 185000,
                'original_price' => 225000,
                'stock'          => 22,
                'image'          => 'desk-lamp.svg',
                'status'         => 'active',
                'is_featured'    => true,
                'badge'          => 'Rekomendasi',
                'rating'         => 4.8,
                'sold_count'     => 78,
                'specs'          => [
                    'Mode Cahaya'  => 'Warm 3000K / Neutral 4500K / Cool 6000K',
                    'Kontrol'      => 'Sensor Sentuh Kapasitif',
                    'Sumber Daya'  => 'USB Type-C 5V / Baterai Internal',
                    'Daya Listrik' => '8 Watt Hemat Energi',
                ],
            ],
            [
                'id'             => 8,
                'category_id'    => 6,
                'category_slug'  => 'kecantikan',
                'category_name'  => 'Perawatan & Kecantikan',
                'name'           => 'Hydra Glow Facial Serum 30ml',
                'slug'           => 'hydra-glow-serum-30ml',
                'short_desc'     => 'Kombinasi Niacinamide 5% dan Hyaluronic Acid untuk hidrasi ringan.',
                'description'    => 'Serum harian bertekstur ringan yang cepat meresap tanpa rasa lengket, membantu menjaga kelembapan skin barrier serta membuat kulit wajah tampak lebih cerah dan terhidrasi.',
                'price'          => 149000,
                'original_price' => 180000,
                'stock'          => 30,
                'image'          => 'skincare-serum.jpg',
                'status'         => 'active',
                'is_featured'    => true,
                'badge'          => 'Pilihan',
                'rating'         => 4.9,
                'sold_count'     => 165,
                'specs'          => [
                    'Isi Bersih'   => '30 ml (Botol Pipet Kaca)',
                    'Kandungan Utama' => 'Niacinamide 5%, Hyaluronic Acid',
                    'Tipe Kulit'   => 'Semua jenis kulit',
                    'Tanpa Alkohol'=> 'Ya, bebas paraben & pewangi berlebih',
                ],
            ],
            [
                'id'             => 9,
                'category_id'    => 5,
                'category_slug'  => 'olahraga',
                'category_name'  => 'Olahraga & Hobi',
                'name'           => 'Botol Minum Sport Tritan 1L',
                'slug'           => 'botol-minum-sport-1l',
                'short_desc'     => 'Kapasitas 1 liter bebas BPA dengan penanda takaran hidrasi harian.',
                'description'    => 'Botol minum berbahan Tritan kokoh yang jernih, ringan, dan tidak meninggalkan bau plastik. Dilengkapi kunci pengaman tutup flip-top sehingga aman dibawa saat berlari atau bersepeda.',
                'price'          => 95000,
                'original_price' => 119000,
                'stock'          => 35,
                'image'          => 'running-bottle.svg',
                'status'         => 'active',
                'is_featured'    => false,
                'badge'          => 'Best Value',
                'rating'         => 4.7,
                'sold_count'     => 190,
                'specs'          => [
                    'Kapasitas'    => '1000 ml (1 Liter)',
                    'Material'     => 'Eastman Tritan Copolyester BPA-Free',
                    'Tutup'        => 'Flip-Top Lock Anti-Tumpah',
                    'Berat Kosong' => '180 gram',
                ],
            ],
            [
                'id'             => 10,
                'category_id'    => 2,
                'category_slug'  => 'fashion',
                'category_name'  => 'Fashion',
                'name'           => 'Jaket Overshirt Denim Casual',
                'slug'           => 'jaket-overshirt-denim',
                'short_desc'     => 'Katun twill denim 12 oz potongan relaxed fit dengan dua saku dada.',
                'description'    => 'Overshirt denim berpotongan modern yang nyaman dipakai sebagai luaran kaos maupun kemeja. Bahan katun twill lembut namun tetap kokoh untuk tampilan kasual sepanjang hari.',
                'price'          => 389000,
                'original_price' => 450000,
                'stock'          => 14,
                'image'          => 'denim-jacket.svg',
                'status'         => 'active',
                'is_featured'    => false,
                'badge'          => 'Edisi Terbatas',
                'rating'         => 4.8,
                'sold_count'     => 64,
                'specs'          => [
                    'Bahan'        => '100% Cotton Denim Twill 12 oz',
                    'Potongan'     => 'Relaxed Fit Unisex',
                    'Ukuran'       => 'S, M, L, XL',
                    'Perawatan'    => 'Cuci air dingin, hindari pemutih',
                ],
            ],
            [
                'id'             => 11,
                'category_id'    => 1,
                'category_slug'  => 'elektronik',
                'category_name'  => 'Elektronik',
                'name'           => 'Adapter Charger Lama (Arsip Nonaktif)',
                'slug'           => 'produk-nonaktif-demo',
                'short_desc'     => 'Produk nonaktif untuk verifikasi aturan bisnis BR-002.',
                'description'    => 'Item ini sengaja disetel berstatus inactive untuk memastikan produk nonaktif tidak pernah muncul di katalog dan tidak dapat diakses/dibeli pelanggan.',
                'price'          => 89000,
                'original_price' => null,
                'stock'          => 0,
                'image'          => 'wireless-headphone.jpg',
                'status'         => 'inactive',
                'is_featured'    => true,
                'badge'          => 'Nonaktif',
                'rating'         => 4.0,
                'sold_count'     => 0,
                'specs'          => [],
            ],
        ];
    }

    /**
     * Daftar kategori aktif beserta jumlah produk aktif di masing-masing kategori.
     *
     * @return list<array<string, mixed>>
     */
    public function getCategoriesWithCount(): array
    {
        $activeProducts = $this->getActiveProducts();
        $counts = [];
        foreach ($activeProducts as $product) {
            $slug = $product['category_slug'];
            $counts[$slug] = ($counts[$slug] ?? 0) + 1;
        }

        $categories = [];
        foreach ($this->getAllCategories() as $category) {
            if (! $category['is_active']) {
                continue;
            }
            $category['product_count'] = $counts[$category['slug']] ?? 0;
            $categories[] = $category;
        }

        return $categories;
    }

    /**
     * Ambil satu kategori berdasarkan slug.
     *
     * @return array<string, mixed>|null
     */
    public function getCategoryBySlug(string $slug): ?array
    {
        foreach ($this->getCategoriesWithCount() as $category) {
            if ($category['slug'] === $slug) {
                return $category;
            }
        }

        return null;
    }

    /**
     * Ambil daftar produk aktif (aturan BR-002: produk nonaktif tidak pernah dikembalikan).
     *
     * @return list<array<string, mixed>>
     */
    public function getActiveProducts(?string $search = null, ?string $categorySlug = null, string $sort = 'featured'): array
    {
        $searchTrimmed = $search !== null ? mb_strtolower(trim($search)) : '';
        $categoryTrimmed = $categorySlug !== null ? trim($categorySlug) : '';

        $filtered = array_values(array_filter(
            $this->getRawProducts(),
            static function (array $product) use ($searchTrimmed, $categoryTrimmed): bool {
                if (($product['status'] ?? 'inactive') !== 'active') {
                    return false;
                }
                if ($categoryTrimmed !== '' && $product['category_slug'] !== $categoryTrimmed) {
                    return false;
                }
                if ($searchTrimmed !== '') {
                    $haystack = mb_strtolower(
                        $product['name'] . ' ' . $product['short_desc'] . ' ' . $product['category_name']
                    );
                    if (mb_strpos($haystack, $searchTrimmed) === false) {
                        return false;
                    }
                }

                return true;
            }
        ));

        usort($filtered, static function (array $a, array $b) use ($sort): int {
            return match ($sort) {
                'price_asc'  => $a['price'] <=> $b['price'],
                'price_desc' => $b['price'] <=> $a['price'],
                'name_asc'   => strcmp($a['name'], $b['name']),
                'bestseller' => $b['sold_count'] <=> $a['sold_count'],
                default      => ($b['is_featured'] <=> $a['is_featured']) ?: ($a['id'] <=> $b['id']),
            };
        });

        return $filtered;
    }

    /**
     * Ambil produk unggulan aktif untuk bagian showcase Landing Page.
     *
     * @return list<array<string, mixed>>
     */
    public function getFeaturedProducts(int $limit = 8): array
    {
        $featured = array_values(array_filter(
            $this->getActiveProducts(),
            static fn (array $product): bool => (bool) ($product['is_featured'] ?? false)
        ));

        return array_slice($featured, 0, $limit);
    }

    /**
     * Ambil detail satu produk aktif berdasarkan slug (null jika nonaktif atau tidak ada).
     *
     * @return array<string, mixed>|null
     */
    public function getProductBySlug(string $slug): ?array
    {
        foreach ($this->getActiveProducts() as $product) {
            if ($product['slug'] === $slug) {
                return $product;
            }
        }

        return null;
    }

    /**
     * Ambil detail satu produk aktif berdasarkan ID (null jika nonaktif atau tidak ada).
     *
     * @return array<string, mixed>|null
     */
    public function getProductById(int $id): ?array
    {
        foreach ($this->getActiveProducts() as $product) {
            if ((int) $product['id'] === $id) {
                return $product;
            }
        }

        return null;
    }

    /**
     * Ambil produk aktif terkait untuk halaman detail produk.
     *
     * @param array<string, mixed> $product
     * @return list<array<string, mixed>>
     */
    public function getRelatedProducts(array $product, int $limit = 4): array
    {
        $active = $this->getActiveProducts();
        $sameCategory = [];
        $others = [];

        foreach ($active as $candidate) {
            if ((int) $candidate['id'] === (int) $product['id']) {
                continue;
            }
            if ($candidate['category_slug'] === $product['category_slug']) {
                $sameCategory[] = $candidate;
            } else {
                $others[] = $candidate;
            }
        }

        return array_slice(array_merge($sameCategory, $others), 0, $limit);
    }

    /**
     * Ringkasan statistik toko untuk bagian hero dan ringkasan Landing Page.
     *
     * @return array<string, mixed>
     */
    public function getStoreStats(): array
    {
        $activeProducts = $this->getActiveProducts();
        $totalSold = array_sum(array_column($activeProducts, 'sold_count'));

        return [
            'active_products' => count($activeProducts),
            'categories'      => count($this->getCategoriesWithCount()),
            'total_sold'      => $totalSold,
            'avg_rating'      => '4.9/5',
        ];
    }

    /**
     * Testimoni pelanggan contoh untuk Landing Page (data non-pribadi).
     *
     * @return list<array<string, string>>
     */
    public function getTestimonials(): array
    {
        return [
            [
                'name'    => 'Raka Pratama',
                'role'    => 'Mahasiswa Teknik Informatika',
                'rating'  => '5.0',
                'comment' => 'Pencarian produk dan filter kategorinya cepat sekali. Detail stok terlihat jelas sebelum barang masuk ke keranjang belanja.',
            ],
            [
                'name'    => 'Nadia Kusuma',
                'role'    => 'Desainer UI/UX',
                'rating'  => '4.9',
                'comment' => 'Tampilan toko bersih, nyaman dibuka dari ponsel maupun laptop, dan alur pemeriksaan pesanan dari awal sampai selesai sangat jelas.',
            ],
            [
                'name'    => 'Bagas Wibowo',
                'role'    => 'Pengguna Terverifikasi',
                'rating'  => '5.0',
                'comment' => 'Mulai dari pemilihan varian, validasi jumlah keranjang, hingga verifikasi pembayaran semuanya terasa rapi dan meyakinkan.',
            ],
        ];
    }

    /**
     * Format angka menjadi mata uang Rupiah (IDR) sesuai PRD Bab 20.
     */
    public static function formatRupiah(int|float $amount): string
    {
        return 'Rp ' . number_format((float) $amount, 0, ',', '.');
    }
}
