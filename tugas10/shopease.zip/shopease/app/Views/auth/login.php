<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<section class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-7 col-lg-5">
                <div class="se-info-card p-4 p-lg-5">
                    <div class="text-center mb-4">
                        <div class="d-inline-flex align-items-center justify-content-center rounded-circle bg-primary bg-opacity-10 text-primary p-3 fs-3 mb-2">
                            <i class="bi bi-person-lock"></i>
                        </div>
                        <h1 class="h3 fw-bold mb-1">Masuk ke ShopEase</h1>
                        <p class="small text-muted mb-0">Gunakan akun customer Anda untuk berbelanja dan memantau pesanan.</p>
                    </div>

                    <form action="<?= route_to('login.attempt') ?>" method="post">
                        <?= csrf_field() ?>
                        <div class="mb-3">
                            <label for="loginEmail" class="form-label fw-semibold">Alamat Email</label>
                            <input type="email" class="form-control" id="loginEmail" name="email" value="<?= esc(old('email')) ?>" placeholder="customer@shopease-demo.local" required>
                        </div>
                        <div class="mb-3">
                            <label for="loginPassword" class="form-label fw-semibold">Kata Sandi</label>
                            <input type="password" class="form-control" id="loginPassword" name="password" placeholder="Minimal 6 karakter" required>
                        </div>
                        <button type="submit" class="btn btn-se-primary w-100 py-2 mb-3">
                            <i class="bi bi-box-arrow-in-right me-2"></i>Masuk Sekarang
                        </button>
                    </form>

                    <div class="alert alert-light border small mb-3">
                        <div class="fw-bold mb-1"><i class="bi bi-key me-1 text-primary"></i>Akun Uji Pembelajaran (Demo):</div>
                        <div>Email: <code>customer@shopease-demo.local</code></div>
                        <div>Password: <code>shopease123</code></div>
                    </div>

                    <div class="text-center small text-muted">
                        Belum punya akun? <a href="<?= route_to('register') ?>" class="fw-semibold text-decoration-none">Daftar Customer Baru</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?= $this->endSection() ?>
