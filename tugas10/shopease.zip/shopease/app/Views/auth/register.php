<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<section class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-5">
                <div class="se-info-card p-4 p-lg-5">
                    <div class="text-center mb-4">
                        <div class="d-inline-flex align-items-center justify-content-center rounded-circle bg-warning bg-opacity-10 text-warning p-3 fs-3 mb-2">
                            <i class="bi bi-person-plus"></i>
                        </div>
                        <h1 class="h3 fw-bold mb-1">Registrasi Customer</h1>
                        <p class="small text-muted mb-0">Buat akun ShopEase dengan password hashing yang aman.</p>
                    </div>

                    <form action="<?= route_to('register.attempt') ?>" method="post">
                        <?= csrf_field() ?>
                        <div class="mb-3">
                            <label for="regName" class="form-label fw-semibold">Nama Lengkap</label>
                            <input type="text" class="form-control" id="regName" name="name" value="<?= esc(old('name')) ?>" placeholder="Contoh: Pelanggan Baru" required>
                        </div>
                        <div class="mb-3">
                            <label for="regEmail" class="form-label fw-semibold">Alamat Email</label>
                            <input type="email" class="form-control" id="regEmail" name="email" value="<?= esc(old('email')) ?>" placeholder="nama@contoh.local" required>
                        </div>
                        <div class="mb-3">
                            <label for="regPassword" class="form-label fw-semibold">Kata Sandi</label>
                            <input type="password" class="form-control" id="regPassword" name="password" placeholder="Minimal 6 karakter" required>
                        </div>
                        <div class="mb-4">
                            <label for="regConfirm" class="form-label fw-semibold">Konfirmasi Kata Sandi</label>
                            <input type="password" class="form-control" id="regConfirm" name="password_confirm" placeholder="Ulangi kata sandi" required>
                        </div>
                        <button type="submit" class="btn btn-se-coral w-100 py-2 mb-3">
                            <i class="bi bi-check2-circle me-2"></i>Daftar Akun
                        </button>
                    </form>

                    <div class="text-center small text-muted">
                        Sudah memiliki akun? <a href="<?= route_to('login') ?>" class="fw-semibold text-decoration-none">Masuk di sini</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?= $this->endSection() ?>
