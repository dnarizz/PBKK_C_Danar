<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<section class="se-page-header py-5">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-2">
                <li class="breadcrumb-item"><a href="<?= route_to('home') ?>" class="text-white-50 text-decoration-none">Beranda</a></li>
                <li class="breadcrumb-item active text-white" aria-current="page">Tentang ShopEase</li>
            </ol>
        </nav>
        <h1 class="h2 fw-bold mb-2">Tentang ShopEase – Online Store</h1>
        <p class="text-white-50 mb-0" style="max-width: 680px;">
            Digitalisasi katalog produk, keranjang belanja, manajemen pesanan, verifikasi pembayaran manual, hingga pelacakan pengiriman berbasis arsitektur MVC CodeIgniter 4.
        </p>
    </div>
</section>

<section class="py-5">
    <div class="container">
        <div class="row g-4 align-items-stretch mb-5">
            <div class="col-lg-7">
                <div class="se-info-card h-100">
                    <div class="se-section-tag mb-2">Latar Belakang &amp; Tujuan Produk</div>
                    <h2 class="h4 fw-bold mb-3">Mengatasi Pencatatan Penjualan Manual dalam Satu Sistem Terpusat</h2>
                    <p class="text-muted">
                        Proses penjualan yang hanya mengandalkan pencatatan manual atau pesan singkat sering menimbulkan ketidakkonsistenan stok, kesalahan rekap pesanan, dan keterlambatan pembaruan status pengiriman. ShopEase hadir sebagai solusi e-commerce terstruktur sekaligus studi kasus penerapan framework CodeIgniter 4.
                    </p>
                    <ul class="list-unstyled d-flex flex-column gap-2 mt-3 mb-0">
                        <?php foreach ($objectives as $goal): ?>
                            <li class="d-flex align-items-start gap-2">
                                <i class="bi bi-check-circle-fill text-success mt-1"></i>
                                <span><?= esc($goal) ?></span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>

            <div class="col-lg-5">
                <div class="se-info-card h-100 bg-light">
                    <div class="se-section-tag mb-2">Arsitektur Sistem (MVC)</div>
                    <h2 class="h5 fw-bold mb-3">Lapisan Teknologi ShopEase</h2>
                    <div class="table-responsive">
                        <table class="table table-sm align-middle mb-0">
                            <tbody>
                                <tr>
                                    <th class="text-muted fw-semibold">Presentation</th>
                                    <td>HTML5, CSS3, Bootstrap 5, JS</td>
                                </tr>
                                <tr>
                                    <th class="text-muted fw-semibold">Routing</th>
                                    <td><code>app/Config/Routes.php</code> (CI4 Named Routes)</td>
                                </tr>
                                <tr>
                                    <th class="text-muted fw-semibold">Controller</th>
                                    <td><code>HomeController</code>, <code>ProductController</code>, <code>CartController</code>, <code>AuthController</code></td>
                                </tr>
                                <tr>
                                    <th class="text-muted fw-semibold">Database Target</th>
                                    <td>MySQL <code>db_shopease</code> (10 Tabel Inti)</td>
                                </tr>
                                <tr>
                                    <th class="text-muted fw-semibold">Keamanan</th>
                                    <td>CSRF Protection, <code>esc()</code>, Password Hashing, Server Validation</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="mb-3">
            <div class="se-section-tag mb-1">Stakeholder &amp; Hak Akses</div>
            <h2 class="h4 fw-bold">Peran Pengguna pada Ekosistem ShopEase</h2>
        </div>

        <div class="row g-4">
            <?php foreach ($actors as $actor): ?>
                <div class="col-md-4">
                    <div class="se-info-card h-100">
                        <div class="d-inline-flex align-items-center justify-content-center rounded-3 bg-<?= esc($actor['badge']) ?> bg-opacity-10 text-<?= esc($actor['badge']) ?> p-3 fs-4 mb-3">
                            <i class="bi <?= esc($actor['icon']) ?>"></i>
                        </div>
                        <h3 class="h5 fw-bold mb-2"><?= esc($actor['role']) ?></h3>
                        <p class="small text-muted mb-0"><?= esc($actor['desc']) ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?= $this->endSection() ?>
