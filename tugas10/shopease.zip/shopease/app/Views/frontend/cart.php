<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<?php use App\Libraries\StoreCatalog; ?>

<section class="se-page-header py-4">
    <div class="container">
        <h1 class="h3 fw-bold mb-1">Keranjang Belanja</h1>
        <p class="text-white-50 mb-0">Subtotal dan total dihitung ulang secara otomatis di backend berdasarkan harga katalog resmi.</p>
    </div>
</section>

<section class="py-5">
    <div class="container">
        <?php if ($items === []): ?>
            <div class="se-info-card text-center py-5">
                <i class="bi bi-cart-x fs-1 text-muted d-block mb-3"></i>
                <h2 class="h5 fw-bold">Keranjang Belanja Masih Kosong</h2>
                <p class="text-muted mb-4">Jelajahi katalog produk unggulan ShopEase dan tambahkan barang pilihan Anda.</p>
                <a href="<?= route_to('catalog') ?>" class="btn btn-se-primary px-4">Mulai Belanja</a>
            </div>
        <?php else: ?>
            <div class="row g-4">
                <div class="col-lg-8">
                    <div class="se-info-card p-0 overflow-hidden">
                        <div class="table-responsive">
                            <table class="table align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th class="ps-4">Produk</th>
                                        <th>Harga</th>
                                        <th style="width: 170px;">Kuantitas</th>
                                        <th>Subtotal</th>
                                        <th class="pe-4 text-end">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($items as $item): ?>
                                        <?php $p = $item['product']; ?>
                                        <tr>
                                            <td class="ps-4">
                                                <div class="d-flex align-items-center gap-3">
                                                    <img src="<?= base_url('assets/images/products/' . esc($p['image'])) ?>"
                                                         alt="<?= esc($p['name']) ?>"
                                                         class="rounded-3 border"
                                                         style="width: 64px; height: 48px; object-fit: cover;">
                                                    <div>
                                                        <a href="<?= route_to('product.detail', $p['slug']) ?>" class="fw-bold text-decoration-none text-dark d-block">
                                                            <?= esc($p['name']) ?>
                                                        </a>
                                                        <span class="small text-muted">Stok tersedia: <?= (int) $p['stock'] ?></span>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="fw-semibold"><?= esc(StoreCatalog::formatRupiah($p['price'])) ?></td>
                                            <td>
                                                <form action="<?= route_to('cart.update') ?>" method="post" class="d-flex gap-1">
                                                    <?= csrf_field() ?>
                                                    <input type="hidden" name="product_id" value="<?= (int) $p['id'] ?>">
                                                    <input type="number" name="quantity" value="<?= (int) $item['quantity'] ?>" min="1" max="<?= (int) $p['stock'] ?>" class="form-control form-control-sm text-center">
                                                    <button type="submit" class="btn btn-sm btn-outline-primary">Ubah</button>
                                                </form>
                                            </td>
                                            <td class="fw-bold text-primary"><?= esc(StoreCatalog::formatRupiah($item['line_total'])) ?></td>
                                            <td class="pe-4 text-end">
                                                <form action="<?= route_to('cart.remove') ?>" method="post">
                                                    <?= csrf_field() ?>
                                                    <input type="hidden" name="product_id" value="<?= (int) $p['id'] ?>">
                                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Hapus">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="se-info-card">
                        <h2 class="h5 fw-bold mb-3">Ringkasan Belanja</h2>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Subtotal Produk</span>
                            <span class="fw-semibold"><?= esc(StoreCatalog::formatRupiah($subtotal)) ?></span>
                        </div>
                        <div class="d-flex justify-content-between mb-3 pb-3 border-bottom">
                            <span class="text-muted">Estimasi Ongkir Flat</span>
                            <span class="fw-semibold"><?= esc(StoreCatalog::formatRupiah($shippingEstimate)) ?></span>
                        </div>
                        <div class="d-flex justify-content-between mb-4">
                            <span class="fw-bold fs-5">Total</span>
                            <span class="fw-bold fs-5 text-primary"><?= esc(StoreCatalog::formatRupiah($grandTotal)) ?></span>
                        </div>
                        <div class="alert alert-info small mb-3">
                            <i class="bi bi-info-circle me-1"></i>Tahap checkout penuh &amp; upload bukti pembayaran tersedia pada modul Praktikum 9–10.
                        </div>
                        <a href="<?= route_to('catalog') ?>" class="btn btn-outline-primary w-100 rounded-3 fw-semibold">
                            Lanjut Belanja Produk Lain
                        </a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</section>

<?= $this->endSection() ?>
