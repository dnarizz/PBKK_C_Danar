<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<section class="se-page-header py-4 py-lg-5">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-2">
                <li class="breadcrumb-item"><a href="<?= route_to('home') ?>" class="text-white-50 text-decoration-none">Beranda</a></li>
                <li class="breadcrumb-item active text-white" aria-current="page">
                    <?= $activeCategory ? esc($activeCategory['name']) : 'Katalog Produk' ?>
                </li>
            </ol>
        </nav>
        <h1 class="h2 fw-bold mb-1">
            <?= $activeCategory ? 'Kategori: ' . esc($activeCategory['name']) : 'Katalog Produk ShopEase' ?>
        </h1>
        <p class="text-white-50 mb-0">
            <?= $activeCategory ? esc($activeCategory['description']) : 'Menampilkan seluruh produk berstatus aktif yang siap ditambahkan ke keranjang belanja.' ?>
        </p>
    </div>
</section>

<section class="py-5">
    <div class="container">
        <div class="row g-4">
            <!-- Sidebar Filter Kategori -->
            <aside class="col-lg-3">
                <div class="se-info-card">
                    <h2 class="h6 fw-bold mb-3">Filter Kategori</h2>
                    <div class="list-group list-group-flush">
                        <a href="<?= route_to('catalog') ?>"
                           class="list-group-item list-group-item-action border-0 rounded-3 mb-1 d-flex justify-content-between align-items-center <?= empty($selectedSlug) ? 'active bg-primary text-white' : '' ?>">
                            <span><i class="bi bi-grid me-2"></i>Semua Produk</span>
                        </a>
                        <?php foreach ($categories as $cat): ?>
                            <a href="<?= route_to('category.show', $cat['slug']) ?>"
                               class="list-group-item list-group-item-action border-0 rounded-3 mb-1 d-flex justify-content-between align-items-center <?= ($selectedSlug ?? '') === $cat['slug'] ? 'active bg-primary text-white' : '' ?>">
                                <span><i class="bi <?= esc($cat['icon']) ?> me-2"></i><?= esc($cat['name']) ?></span>
                                <span class="badge <?= ($selectedSlug ?? '') === $cat['slug'] ? 'bg-white text-primary' : 'text-bg-light' ?>">
                                    <?= (int) $cat['product_count'] ?>
                                </span>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            </aside>

            <!-- Daftar Produk & Kontrol Pencarian -->
            <div class="col-lg-9">
                <div class="bg-white border rounded-4 p-3 mb-4 shadow-sm">
                    <form method="get" action="<?= $activeCategory ? route_to('category.show', $activeCategory['slug']) : route_to('catalog') ?>" class="row g-2 align-items-center">
                        <?php if (! $activeCategory && ! empty($selectedSlug)): ?>
                            <input type="hidden" name="category" value="<?= esc($selectedSlug) ?>">
                        <?php endif; ?>
                        <div class="col-md-5">
                            <div class="input-group">
                                <span class="input-group-text bg-light border-end-0"><i class="bi bi-search"></i></span>
                                <input type="search" name="q" value="<?= esc($searchQuery) ?>" class="form-control border-start-0" placeholder="Cari nama produk...">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <select name="sort" class="form-select" aria-label="Urutkan produk">
                                <option value="featured" <?= $sort === 'featured' ? 'selected' : '' ?>>Urutkan: Unggulan</option>
                                <option value="bestseller" <?= $sort === 'bestseller' ? 'selected' : '' ?>>Terlaris</option>
                                <option value="price_asc" <?= $sort === 'price_asc' ? 'selected' : '' ?>>Harga Terendah</option>
                                <option value="price_desc" <?= $sort === 'price_desc' ? 'selected' : '' ?>>Harga Tertinggi</option>
                                <option value="name_asc" <?= $sort === 'name_asc' ? 'selected' : '' ?>>Nama (A-Z)</option>
                            </select>
                        </div>
                        <div class="col-md-3 d-grid">
                            <button type="submit" class="btn btn-se-primary">Terapkan</button>
                        </div>
                    </form>
                </div>

                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div class="small text-muted">
                        Menampilkan <strong><?= count($products) ?></strong> produk aktif
                        <?php if ($searchQuery !== ''): ?>
                            untuk kata kunci &ldquo;<strong><?= esc($searchQuery) ?></strong>&rdquo;
                        <?php endif; ?>
                    </div>
                    <?php if ($searchQuery !== '' || ! empty($selectedSlug)): ?>
                        <a href="<?= route_to('catalog') ?>" class="small text-decoration-none">Reset Filter</a>
                    <?php endif; ?>
                </div>

                <?php if ($products === []): ?>
                    <div class="se-info-card text-center py-5">
                        <i class="bi bi-search fs-1 text-muted d-block mb-3"></i>
                        <h2 class="h5 fw-bold">Produk Tidak Ditemukan</h2>
                        <p class="text-muted mb-3">Coba ubah kata kunci pencarian atau pilih kategori lain.</p>
                        <a href="<?= route_to('catalog') ?>" class="btn btn-se-primary">Lihat Semua Produk</a>
                    </div>
                <?php else: ?>
                    <div class="row g-4">
                        <?php foreach ($products as $product): ?>
                            <?= view('partials/product_card', ['product' => $product, 'colClass' => 'col-12 col-sm-6 col-xl-4']) ?>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?= $this->endSection() ?>
