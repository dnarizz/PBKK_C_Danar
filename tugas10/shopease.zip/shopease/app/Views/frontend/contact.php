<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<section class="se-page-header py-5">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-2">
                <li class="breadcrumb-item"><a href="<?= route_to('home') ?>" class="text-white-50 text-decoration-none">Beranda</a></li>
                <li class="breadcrumb-item active text-white" aria-current="page">Hubungi Kami</li>
            </ol>
        </nav>
        <h1 class="h2 fw-bold mb-2">Hubungi Layanan Pelanggan ShopEase</h1>
        <p class="text-white-50 mb-0" style="max-width: 650px;">
            Punya pertanyaan seputar ketersediaan produk, verifikasi pembayaran manual, atau pengiriman? Kirimkan pesan Anda melalui formulir resmi di bawah ini.
        </p>
    </div>
</section>

<section class="py-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-5">
                <div class="se-info-card mb-4">
                    <div class="se-section-tag mb-2">Informasi Kontak Demo</div>
                    <h2 class="h5 fw-bold mb-3">Saluran Bantuan Resmi</h2>
                    <div class="d-flex flex-column gap-3">
                        <div class="d-flex align-items-start gap-3">
                            <div class="rounded-3 bg-primary bg-opacity-10 text-primary p-2"><i class="bi bi-envelope-fill"></i></div>
                            <div>
                                <div class="fw-semibold small">Email Dukungan</div>
                                <div class="text-muted small">support@shopease-demo.local</div>
                            </div>
                        </div>
                        <div class="d-flex align-items-start gap-3">
                            <div class="rounded-3 bg-primary bg-opacity-10 text-primary p-2"><i class="bi bi-geo-alt-fill"></i></div>
                            <div>
                                <div class="fw-semibold small">Lokasi Operasional (Contoh)</div>
                                <div class="text-muted small">Kampus Teknik Informatika, Surabaya, Jawa Timur</div>
                            </div>
                        </div>
                        <div class="d-flex align-items-start gap-3">
                            <div class="rounded-3 bg-primary bg-opacity-10 text-primary p-2"><i class="bi bi-clock-fill"></i></div>
                            <div>
                                <div class="fw-semibold small">Jam Layanan Verifikasi</div>
                                <div class="text-muted small">Senin – Sabtu, 08.00 – 17.00 WIB</div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="se-info-card">
                    <div class="se-section-tag mb-2">Tanya Jawab Singkat</div>
                    <div class="accordion accordion-flush" id="faqAccordion">
                        <?php foreach ($faqs as $idx => $faq): ?>
                            <div class="accordion-item">
                                <h3 class="accordion-header">
                                    <button class="accordion-button <?= $idx > 0 ? 'collapsed' : '' ?> fw-semibold small px-0" type="button" data-bs-toggle="collapse" data-bs-target="#faq<?= $idx ?>">
                                        <?= esc($faq['q']) ?>
                                    </button>
                                </h3>
                                <div id="faq<?= $idx ?>" class="accordion-collapse collapse <?= $idx === 0 ? 'show' : '' ?>" data-bs-parent="#faqAccordion">
                                    <div class="accordion-body px-0 small text-muted">
                                        <?= esc($faq['a']) ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <div class="col-lg-7">
                <div class="se-info-card">
                    <div class="se-section-tag mb-1">Formulir Pesan</div>
                    <h2 class="h4 fw-bold mb-3">Kirim Pertanyaan atau Masukan</h2>
                    <form action="<?= route_to('contact.send') ?>" method="post" novalidate>
                        <?= csrf_field() ?>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label for="contactName" class="form-label fw-semibold">Nama Lengkap</label>
                                <input type="text" class="form-control" id="contactName" name="name" value="<?= esc(old('name')) ?>" placeholder="Contoh: Pelanggan Contoh" required>
                            </div>
                            <div class="col-md-6">
                                <label for="contactEmail" class="form-label fw-semibold">Alamat Email</label>
                                <input type="email" class="form-control" id="contactEmail" name="email" value="<?= esc(old('email')) ?>" placeholder="nama@contoh.local" required>
                            </div>
                            <div class="col-12">
                                <label for="contactSubject" class="form-label fw-semibold">Subjek Pesan</label>
                                <input type="text" class="form-control" id="contactSubject" name="subject" value="<?= esc(old('subject')) ?>" placeholder="Misal: Konfirmasi stok atau verifikasi pembayaran" required>
                            </div>
                            <div class="col-12">
                                <label for="contactMessage" class="form-label fw-semibold">Isi Pesan</label>
                                <textarea class="form-control" id="contactMessage" name="message" rows="5" placeholder="Tuliskan pertanyaan Anda minimal 10 karakter..." required><?= esc(old('message')) ?></textarea>
                            </div>
                            <div class="col-12 pt-2">
                                <button type="submit" class="btn btn-se-primary px-4 py-2">
                                    <i class="bi bi-send me-2"></i>Kirim Pesan Sekarang
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?= $this->endSection() ?>
