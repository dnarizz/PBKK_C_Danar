<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<!-- 1. Hero Banner -->
<section class="se-hero py-5">
    <div class="container py-lg-4">
        <div class="row align-items-center g-4 g-lg-5">
            <div class="col-lg-6">
                <div class="se-hero-eyebrow mb-3">
                    <i class="bi bi-stars text-warning"></i>
                    <span>ShopEase Online Store &bull; CodeIgniter 4 MVC</span>
                </div>
                <h1 class="se-hero-title mb-3">
                    Belanja Kebutuhan Harian Lebih Cepat, Aman, dan Terstruktur.
                </h1>
                <p class="se-hero-subtitle mb-4">
                    Jelajahi katalog produk terkurasi mulai dari elektronik, fashion kasual, hingga perlengkapan kerja. Harga jelas dalam Rupiah, stok tervalidasi di server, dan alur transaksi mudah dipantau.
                </p>

                <div class="d-flex flex-wrap gap-3 mb-4">
                    <a href="<?= route_to('catalog') ?>" class="btn btn-se-coral btn-lg px-4">
                        <i class="bi bi-bag-check me-2"></i>Jelajahi Katalog
                    </a>
                    <a href="<?= route_to('about') ?>" class="btn btn-outline-light btn-lg px-4 rounded-3 fw-semibold">
                        Pelajari Alur Toko
                    </a>
                </div>

                <div class="row g-2 g-sm-3 pt-2">
                    <div class="col-6 col-sm-3">
                        <div class="se-hero-stat">
                            <div class="fs-5 fw-bold"><?= (int) $storeStats['active_products'] ?>+</div>
                            <div class="small text-white-50">Produk Aktif</div>
                        </div>
                    </div>
                    <div class="col-6 col-sm-3">
                        <div class="se-hero-stat">
                            <div class="fs-5 fw-bold"><?= (int) $storeStats['categories'] ?></div>
                            <div class="small text-white-50">Kategori Pilihan</div>
                        </div>
                    </div>
                    <div class="col-6 col-sm-3">
                        <div class="se-hero-stat">
                            <div class="fs-5 fw-bold"><?= (int) $storeStats['total_sold'] ?>+</div>
                            <div class="small text-white-50">Item Terjual</div>
                        </div>
                    </div>
                    <div class="col-6 col-sm-3">
                        <div class="se-hero-stat">
                            <div class="fs-5 fw-bold"><?= esc($storeStats['avg_rating']) ?></div>
                            <div class="small text-white-50">Kepuasan</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="se-hero-visual-wrap">
                    <div class="se-hero-image-card">
                        <img src="<?= base_url('assets/images/hero-showcase.jpg') ?>"
                             alt="Etalase Produk Unggulan ShopEase">
                    </div>

                    <div class="row g-2 mt-3">
                        <div class="col-sm-6">
                            <div class="se-hero-floating d-flex align-items-center gap-3">
                                <div class="rounded-3 bg-primary bg-opacity-10 text-primary p-2 fs-4">
                                    <i class="bi bi-shield-check"></i>
                                </div>
                                <div>
                                    <div class="fw-bold small">Stok Tervalidasi Server</div>
                                    <div class="text-muted" style="font-size: 0.78rem;">Cegah selisih stok saat checkout</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="se-hero-floating d-flex align-items-center gap-3">
                                <div class="rounded-3 bg-success bg-opacity-10 text-success p-2 fs-4">
                                    <i class="bi bi-truck"></i>
                                </div>
                                <div>
                                    <div class="fw-bold small">Pelacakan Pesanan Jelas</div>
                                    <div class="text-muted" style="font-size: 0.78rem;">Status bayar &amp; pengiriman terpisah</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- 2. Kategori Pilihan -->
<section class="py-5" id="kategori">
    <div class="container">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-end mb-4 gap-2">
            <div>
                <div class="se-section-tag mb-1">Eksplorasi Kategori</div>
                <h2 class="se-section-title h3 mb-0">Belanja Berdasarkan Kebutuhan Anda</h2>
            </div>
            <a href="<?= route_to('catalog') ?>" class="text-decoration-none fw-semibold text-primary">
                Lihat Semua Katalog <i class="bi bi-arrow-right ms-1"></i>
            </a>
        </div>

        <div class="row g-3">
            <?php foreach ($categories as $cat): ?>
                <div class="col-6 col-md-4 col-lg-2">
                    <a href="<?= route_to('category.show', $cat['slug']) ?>" class="se-category-card">
                        <div class="se-category-icon" style="background-color: <?= esc($cat['accent']) ?>1A; color: <?= esc($cat['accent']) ?>;">
                            <i class="bi <?= esc($cat['icon']) ?>"></i>
                        </div>
                        <h3 class="h6 fw-bold mb-1"><?= esc($cat['name']) ?></h3>
                        <span class="small text-muted mt-auto"><?= (int) $cat['product_count'] ?> Produk Aktif</span>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- 3. Produk Unggulan -->
<section class="py-5 bg-white border-top border-bottom" id="produk-unggulan">
    <div class="container">
        <div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-end mb-4 gap-3">
            <div>
                <div class="se-section-tag mb-1">Pilihan Editor</div>
                <h2 class="se-section-title h3 mb-1">Produk Unggulan ShopEase</h2>
                <p class="text-muted mb-0">Menampilkan produk berstatus aktif dengan ketersediaan stok siap kirim.</p>
            </div>

            <div class="d-flex flex-wrap gap-2" role="group" aria-label="Filter Produk Unggulan">
                <button type="button" class="se-filter-pill active" data-filter-cat="all">Semua</button>
                <?php foreach ($categories as $cat): ?>
                    <?php if ((int) $cat['product_count'] > 0): ?>
                        <button type="button" class="se-filter-pill" data-filter-cat="<?= esc($cat['slug']) ?>">
                            <?= esc($cat['name']) ?>
                        </button>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="row g-4">
            <?php foreach ($featuredProducts as $product): ?>
                <?= view('partials/product_card', ['product' => $product, 'showFilterAttr' => true]) ?>
            <?php endforeach; ?>
        </div>

        <div class="text-center mt-5">
            <a href="<?= route_to('catalog') ?>" class="btn btn-se-primary px-4 py-2">
                Buka Seluruh Katalog (<?= (int) $storeStats['active_products'] ?> Produk) <i class="bi bi-arrow-right ms-1"></i>
            </a>
        </div>
    </div>
</section>

<!-- 4. Alur Belanja & Ekosistem Peran PRD -->
<section class="py-5">
    <div class="container">
        <div class="text-center mx-auto mb-5" style="max-width: 680px;">
            <div class="se-section-tag mb-1">Pengalaman Pengguna</div>
            <h2 class="se-section-title h3 mb-2">Alur Belanja Mudah dari Katalog hingga Pengiriman</h2>
            <p class="text-muted mb-0">Dirancang sesuai Product Requirement Document ShopEase untuk memastikan proses belanja pelanggan dan pemenuhan pesanan oleh tim toko berjalan konsisten.</p>
        </div>

        <div class="row g-3 mb-5">
            <div class="col-12 col-md-6 col-lg-3">
                <div class="se-step-card">
                    <div class="se-step-num mb-3">01</div>
                    <h3 class="h6 fw-bold">Cari &amp; Filter Katalog</h3>
                    <p class="small text-muted mb-0">Temukan produk aktif melalui kolom pencarian, kategori, atau pengurutan harga secara cepat.</p>
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-3">
                <div class="se-step-card">
                    <div class="se-step-num mb-3">02</div>
                    <h3 class="h6 fw-bold">Periksa Detail &amp; Stok</h3>
                    <p class="small text-muted mb-0">Tinjau deskripsi lengkap, spesifikasi, harga resmi Rupiah, serta jumlah stok tersedia.</p>
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-3">
                <div class="se-step-card">
                    <div class="se-step-num mb-3">03</div>
                    <h3 class="h6 fw-bold">Keranjang &amp; Checkout</h3>
                    <p class="small text-muted mb-0">Sistem memvalidasi batas kuantitas terhadap stok dan menghitung ulang subtotal di backend.</p>
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-3">
                <div class="se-step-card">
                    <div class="se-step-num mb-3">04</div>
                    <h3 class="h6 fw-bold">Verifikasi &amp; Kirim</h3>
                    <p class="small text-muted mb-0">Bukti pembayaran diverifikasi admin dan nomor resi pengiriman diperbarui oleh operator toko.</p>
                </div>
            </div>
        </div>

        <!-- Ringkasan 3 Aktor -->
        <div class="row g-3">
            <div class="col-lg-4">
                <div class="se-info-card h-100 d-flex gap-3">
                    <div class="fs-3 text-primary"><i class="bi bi-person-badge"></i></div>
                    <div>
                        <h3 class="h6 fw-bold mb-1">Customer</h3>
                        <p class="small text-muted mb-0">Menjelajahi katalog, mengelola keranjang, melakukan checkout, mengunggah bukti pembayaran, dan memantau riwayat pesanan.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="se-info-card h-100 d-flex gap-3">
                    <div class="fs-3 text-warning"><i class="bi bi-shield-lock"></i></div>
                    <div>
                        <h3 class="h6 fw-bold mb-1">Administrator</h3>
                        <p class="small text-muted mb-0">Mengelola kategori, produk, stok, memverifikasi pembayaran manual, serta memantau ringkasan penjualan toko.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="se-info-card h-100 d-flex gap-3">
                    <div class="fs-3 text-success"><i class="bi bi-box2-heart"></i></div>
                    <div>
                        <h3 class="h6 fw-bold mb-1">Operator Toko</h3>
                        <p class="small text-muted mb-0">Menyiapkan item pesanan, memperbarui status pemrosesan barang, dan menginput kurir beserta nomor resi.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- 5. Banner Promo Mingguan -->
<section class="py-3">
    <div class="container">
        <div class="se-promo-banner p-4 p-lg-5">
            <div class="row align-items-center g-4">
                <div class="col-lg-8">
                    <span class="badge text-bg-warning text-dark fw-bold mb-3 px-3 py-2 rounded-pill">
                        <i class="bi bi-lightning-charge-fill me-1"></i>Promo Koleksi Elektronik
                    </span>
                    <h2 class="h2 fw-bold mb-2">Upgrade Perangkat Kerja &amp; Audio Harian Anda</h2>
                    <p class="mb-0 text-white-50">
                        Dapatkan Wireless Headphone ANC Pro, Smart Watch Fit Series, dan Keyboard Mekanikal 75% dengan penawaran khusus mahasiswa serta garansi toko terjamin.
                    </p>
                </div>
                <div class="col-lg-4 text-lg-end">
                    <a href="<?= route_to('category.show', 'elektronik') ?>" class="btn btn-se-coral btn-lg px-4">
                        Lihat Kategori Elektronik <i class="bi bi-arrow-right ms-1"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- 6. Testimoni Pelanggan & CTA Akhir -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-4">
            <div class="se-section-tag mb-1">Ulasan Pelanggan</div>
            <h2 class="se-section-title h3">Dipercaya untuk Pengalaman Belanja yang Rapi</h2>
        </div>

        <div class="row g-4 mb-5">
            <?php foreach ($testimonials as $item): ?>
                <div class="col-md-4">
                    <div class="se-info-card h-100 d-flex flex-column">
                        <div class="text-warning mb-2">
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <span class="ms-1 text-dark fw-semibold small"><?= esc($item['rating']) ?></span>
                        </div>
                        <p class="text-muted small flex-grow-1 mb-3">&ldquo;<?= esc($item['comment']) ?>&rdquo;</p>
                        <div class="border-top pt-3">
                            <div class="fw-bold small"><?= esc($item['name']) ?></div>
                            <div class="text-muted" style="font-size: 0.78rem;"><?= esc($item['role']) ?></div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="bg-white border rounded-4 p-4 p-lg-5 text-center shadow-sm">
            <h2 class="h3 fw-bold mb-2">Siap Mulai Belanja di ShopEase?</h2>
            <p class="text-muted mx-auto mb-4" style="max-width: 560px;">
                Buat akun customer untuk mulai mengelola keranjang belanja, atau langsung telusuri seluruh produk aktif pada katalog kami.
            </p>
            <div class="d-flex justify-content-center flex-wrap gap-3">
                <a href="<?= route_to('catalog') ?>" class="btn btn-se-primary px-4 py-2">
                    <i class="bi bi-grid me-2"></i>Buka Katalog Produk
                </a>
                <a href="<?= route_to('register') ?>" class="btn btn-outline-primary rounded-3 fw-semibold px-4 py-2">
                    Daftar Akun Customer
                </a>
            </div>
        </div>
    </div>
</section>

<?= $this->endSection() ?>
