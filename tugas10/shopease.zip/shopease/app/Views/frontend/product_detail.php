<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<?php use App\Libraries\StoreCatalog; ?>

<section class="py-4 py-lg-5">
    <div class="container">
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= route_to('home') ?>" class="text-decoration-none">Beranda</a></li>
                <li class="breadcrumb-item"><a href="<?= route_to('catalog') ?>" class="text-decoration-none">Katalog</a></li>
                <li class="breadcrumb-item"><a href="<?= route_to('category.show', $product['category_slug']) ?>" class="text-decoration-none"><?= esc($product['category_name']) ?></a></li>
                <li class="breadcrumb-item active" aria-current="page"><?= esc($product['name']) ?></li>
            </ol>
        </nav>

        <div class="bg-white border rounded-4 p-4 p-lg-5 shadow-sm mb-5">
            <div class="row g-4 g-lg-5 align-items-start">
                <div class="col-lg-6">
                    <div class="se-detail-stage">
                        <img src="<?= base_url('assets/images/products/' . esc($product['image'])) ?>"
                             alt="<?= esc($product['name']) ?>">
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="d-flex flex-wrap align-items-center gap-2 mb-2">
                        <a href="<?= route_to('category.show', $product['category_slug']) ?>" class="badge text-bg-primary bg-opacity-10 text-primary text-decoration-none px-3 py-2">
                            <?= esc($product['category_name']) ?>
                        </a>
                        <?php if (! empty($product['badge'])): ?>
                            <span class="badge text-bg-warning text-dark px-3 py-2"><?= esc($product['badge']) ?></span>
                        <?php endif; ?>
                        <span class="se-stock-pill">Stok Tersedia: <?= (int) $product['stock'] ?> unit</span>
                    </div>

                    <h1 class="h2 fw-bold mb-2"><?= esc($product['name']) ?></h1>

                    <div class="d-flex align-items-center gap-3 small text-muted mb-3">
                        <span class="text-warning fw-semibold"><i class="bi bi-star-fill me-1"></i><?= esc((string) $product['rating']) ?></span>
                        <span>&bull;</span>
                        <span><?= (int) $product['sold_count'] ?> unit terjual</span>
                    </div>

                    <div class="mb-4 pb-3 border-bottom">
                        <div class="display-6 fw-bold text-primary mb-1"><?= esc(StoreCatalog::formatRupiah($product['price'])) ?></div>
                        <?php if (! empty($product['original_price'])): ?>
                            <div class="text-muted text-decoration-line-through small">
                                Harga Normal: <?= esc(StoreCatalog::formatRupiah($product['original_price'])) ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <p class="text-muted mb-4"><?= esc($product['description']) ?></p>

                    <form action="<?= route_to('cart.add') ?>" method="post" class="mb-4">
                        <?= csrf_field() ?>
                        <input type="hidden" name="product_id" value="<?= (int) $product['id'] ?>">

                        <div class="row g-3 align-items-end">
                            <div class="col-sm-4">
                                <label for="detailQty" class="form-label fw-semibold small">Jumlah Beli</label>
                                <div class="input-group" data-qty-stepper>
                                    <button class="btn btn-outline-secondary" type="button" data-qty-minus aria-label="Kurangi jumlah">-</button>
                                    <input type="number" id="detailQty" name="quantity" class="form-control text-center fw-bold" value="1" min="1" max="<?= (int) $product['stock'] ?>" required>
                                    <button class="btn btn-outline-secondary" type="button" data-qty-plus aria-label="Tambah jumlah">+</button>
                                </div>
                            </div>
                            <div class="col-sm-8 d-grid">
                                <button type="submit" class="btn btn-se-coral btn-lg">
                                    <i class="bi bi-cart-plus me-2"></i>Tambah ke Keranjang
                                </button>
                            </div>
                        </div>
                    </form>

                    <?php if (! empty($product['specs']) && is_array($product['specs'])): ?>
                        <div class="border rounded-3 p-3 bg-light">
                            <h2 class="h6 fw-bold mb-2">Spesifikasi Produk</h2>
                            <table class="table table-sm table-borderless mb-0 small">
                                <tbody>
                                    <?php foreach ($product['specs'] as $specKey => $specVal): ?>
                                        <tr>
                                            <td class="text-muted" style="width: 40%;"><?= esc($specKey) ?></td>
                                            <td class="fw-semibold"><?= esc($specVal) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div>
            <div class="d-flex justify-content-between align-items-end mb-3">
                <h2 class="h4 fw-bold mb-0">Produk Terkait Lainnya</h2>
                <a href="<?= route_to('catalog') ?>" class="text-decoration-none fw-semibold small">Lihat Semua</a>
            </div>
            <div class="row g-4">
                <?php foreach ($relatedProducts as $rel): ?>
                    <?= view('partials/product_card', ['product' => $rel]) ?>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>

<?= $this->endSection() ?>
