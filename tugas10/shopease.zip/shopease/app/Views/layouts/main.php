<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?= esc($metaDescription ?? 'ShopEase Online Store – Katalog belanja modern berbasis CodeIgniter 4 dan Bootstrap 5.') ?>">
    <title><?= esc($title ?? 'ShopEase – Online Store') ?></title>
    <link rel="stylesheet" href="<?= base_url('assets/vendor/bootstrap/css/bootstrap.min.css') ?>">
    <link rel="stylesheet" href="<?= base_url('assets/vendor/bootstrap-icons/bootstrap-icons.min.css') ?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/shopease.css') ?>">
</head>
<body class="d-flex flex-column min-vh-100">

    <!-- Top Announcement Bar -->
    <div class="se-topbar py-2">
        <div class="container d-flex flex-wrap justify-content-between align-items-center gap-2">
            <div class="d-flex align-items-center gap-2">
                <i class="bi bi-shield-check text-warning"></i>
                <span>Belanja aman &amp; terstruktur<span class="d-none d-sm-inline"> — Stok tervalidasi di server &bull; Transaksi Rupiah (IDR)</span></span>
            </div>
            <div class="d-none d-md-flex align-items-center gap-3">
                <a href="<?= route_to('about') ?>" class="text-decoration-none text-light opacity-75">Tentang ShopEase</a>
                <span class="opacity-50">|</span>
                <a href="<?= route_to('contact') ?>" class="text-decoration-none text-light opacity-75">Pusat Bantuan</a>
            </div>
        </div>
    </div>

    <!-- Header & Navigasi -->
    <?= $this->include('partials/navbar') ?>

    <!-- Flash Notifications -->
    <?php
    $flashSuccess = session()->getFlashdata('success');
    $flashError   = session()->getFlashdata('error');
    $flashErrors  = session()->getFlashdata('errors');
    ?>
    <?php if ($flashSuccess || $flashError || ! empty($flashErrors)): ?>
        <div class="container mt-3">
            <?php if ($flashSuccess): ?>
                <div class="alert alert-success alert-dismissible fade show shadow-sm border-0 rounded-3" role="alert">
                    <i class="bi bi-check-circle-fill me-2"></i><?= esc($flashSuccess) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button>
                </div>
            <?php endif; ?>

            <?php if ($flashError): ?>
                <div class="alert alert-danger alert-dismissible fade show shadow-sm border-0 rounded-3" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i><?= esc($flashError) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button>
                </div>
            <?php endif; ?>

            <?php if (is_array($flashErrors) && $flashErrors !== []): ?>
                <div class="alert alert-danger alert-dismissible fade show shadow-sm border-0 rounded-3" role="alert">
                    <div class="fw-semibold mb-1"><i class="bi bi-exclamation-circle-fill me-2"></i>Periksa kembali isian formulir:</div>
                    <ul class="mb-0 ps-3">
                        <?php foreach ($flashErrors as $err): ?>
                            <li><?= esc($err) ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <!-- Main Content -->
    <main class="flex-grow-1">
        <?= $this->renderSection('content') ?>
    </main>

    <!-- Footer -->
    <?= $this->include('partials/footer') ?>

    <script src="<?= base_url('assets/vendor/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
    <script src="<?= base_url('assets/js/shopease.js') ?>"></script>
</body>
</html>
