<?php
$categories = $categories ?? [];
?>
<footer class="se-footer pt-5 pb-4 mt-auto">
    <div class="container">
        <div class="row g-4 pb-4 border-bottom border-secondary border-opacity-25">
            <div class="col-lg-4">
                <div class="d-flex align-items-center gap-2 mb-3">
                    <span class="fs-4 fw-bold text-white">Shop<span class="text-primary">Ease</span></span>
                    <span class="badge text-bg-primary bg-opacity-25 text-info border border-info border-opacity-25">CI4 Store</span>
                </div>
                <p class="small text-light opacity-75 mb-3">
                    Aplikasi toko online berbasis web dengan arsitektur MVC CodeIgniter 4. Menghadirkan katalog terpusat, validasi stok server-side, keranjang belanja, hingga alur verifikasi transaksi yang transparan.
                </p>
                <div class="d-flex gap-2 small">
                    <span class="badge bg-white bg-opacity-10 text-light py-2 px-3"><i class="bi bi-currency-exchange me-1"></i>Rupiah (IDR)</span>
                    <span class="badge bg-white bg-opacity-10 text-light py-2 px-3"><i class="bi bi-shield-lock me-1"></i>CSRF Protected</span>
                </div>
            </div>

            <div class="col-6 col-lg-2">
                <h6 class="text-white fw-bold mb-3">Navigasi</h6>
                <ul class="list-unstyled d-flex flex-column gap-2 small">
                    <li><a href="<?= route_to('home') ?>">Beranda</a></li>
                    <li><a href="<?= route_to('catalog') ?>">Katalog Produk</a></li>
                    <li><a href="<?= route_to('about') ?>">Tentang Kami</a></li>
                    <li><a href="<?= route_to('contact') ?>">Hubungi Kami</a></li>
                    <li><a href="<?= route_to('cart') ?>">Keranjang Belanja</a></li>
                </ul>
            </div>

            <div class="col-6 col-lg-3">
                <h6 class="text-white fw-bold mb-3">Kategori Pilihan</h6>
                <ul class="list-unstyled d-flex flex-column gap-2 small">
                    <?php foreach (array_slice($categories, 0, 5) as $cat): ?>
                        <li>
                            <a href="<?= route_to('category.show', $cat['slug']) ?>">
                                <i class="bi <?= esc($cat['icon']) ?> me-1 opacity-75"></i><?= esc($cat['name']) ?>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div class="col-lg-3">
                <h6 class="text-white fw-bold mb-3">Layanan &amp; Kontak Demo</h6>
                <ul class="list-unstyled d-flex flex-column gap-2 small opacity-75">
                    <li><i class="bi bi-envelope me-2 text-primary"></i>support@shopease-demo.local</li>
                    <li><i class="bi bi-geo-alt me-2 text-primary"></i>Surabaya, Jawa Timur (Lingkungan Uji)</li>
                    <li><i class="bi bi-clock me-2 text-primary"></i>Senin – Sabtu, 08.00 – 17.00 WIB</li>
                </ul>
            </div>
        </div>

        <div class="pt-3 d-flex flex-column flex-md-row justify-content-between align-items-center gap-2 small opacity-75">
            <span>&copy; <?= date('Y') ?> ShopEase Online Store &mdash; Proyek Praktikum Web Framework (CodeIgniter 4 &amp; Bootstrap 5).</span>
            <span>Data katalog dan kontak menggunakan data demonstrasi pembelajaran.</span>
        </div>
    </div>
</footer>
