<?php
$activeNav   = $activeNav ?? '';
$categories  = $categories ?? [];
$cartCount   = (int) ($cartCount ?? 0);
$currentUser = $currentUser ?? null;
$searchQuery = $searchQuery ?? '';
?>
<header class="se-navbar sticky-top">
    <nav class="navbar navbar-expand-lg py-2" aria-label="Navigasi Utama ShopEase">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center gap-2 me-4" href="<?= route_to('home') ?>">
                <svg width="36" height="36" viewBox="0 0 36 36" fill="none" aria-hidden="true">
                    <rect width="36" height="36" rx="10" fill="#1E3A8A"/>
                    <path d="M11 14.5C11 11.4624 13.4624 9 16.5 9H19.5C22.5376 9 25 11.4624 25 14.5V15H11V14.5Z" stroke="#93C5FD" stroke-width="2"/>
                    <rect x="8.5" y="14" width="19" height="14" rx="4" fill="#2563EB"/>
                    <path d="M14 20.5L17 23.5L22.5 18" stroke="#FFFFFF" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                <span class="se-brand-text">Shop<span>Ease</span></span>
            </a>

            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#shopeaseNavbar" aria-controls="shopeaseNavbar" aria-expanded="false" aria-label="Buka menu navigasi">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="shopeaseNavbar">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 gap-lg-1">
                    <li class="nav-item">
                        <a class="nav-link <?= $activeNav === 'home' ? 'active' : '' ?>" href="<?= route_to('home') ?>">Beranda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= $activeNav === 'catalog' ? 'active' : '' ?>" href="<?= route_to('catalog') ?>">Katalog</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Kategori
                        </a>
                        <ul class="dropdown-menu shadow border-0 rounded-3 p-2">
                            <?php foreach ($categories as $cat): ?>
                                <li>
                                    <a class="dropdown-item rounded-2 d-flex justify-content-between align-items-center py-2" href="<?= route_to('category.show', $cat['slug']) ?>">
                                        <span><i class="bi <?= esc($cat['icon']) ?> me-2 text-primary"></i><?= esc($cat['name']) ?></span>
                                        <span class="badge text-bg-light ms-3"><?= (int) $cat['product_count'] ?></span>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= $activeNav === 'about' ? 'active' : '' ?>" href="<?= route_to('about') ?>">Tentang</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= $activeNav === 'contact' ? 'active' : '' ?>" href="<?= route_to('contact') ?>">Kontak</a>
                    </li>
                </ul>

                <form class="d-flex se-search-group my-2 my-lg-0 me-lg-3" action="<?= route_to('catalog') ?>" method="get" role="search">
                    <input class="form-control" type="search" name="q" value="<?= esc($searchQuery) ?>" placeholder="Cari produk..." aria-label="Cari produk">
                    <button class="btn btn-se-primary px-3" type="submit" aria-label="Cari">
                        <i class="bi bi-search"></i>
                    </button>
                </form>

                <div class="d-flex align-items-center gap-2">
                    <a href="<?= route_to('cart') ?>" class="btn btn-outline-secondary position-relative rounded-3 px-3" aria-label="Keranjang Belanja">
                        <i class="bi bi-cart3"></i>
                        <span class="ms-1 d-lg-none d-xl-inline">Keranjang</span>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                            <?= $cartCount ?>
                        </span>
                    </a>

                    <?php if (is_array($currentUser)): ?>
                        <div class="dropdown">
                            <button class="btn btn-se-primary dropdown-toggle px-3" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="bi bi-person-circle me-1"></i><?= esc($currentUser['name']) ?>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end shadow border-0 rounded-3">
                                <li class="px-3 py-2 small text-muted border-bottom">
                                    Peran: <strong class="text-uppercase"><?= esc($currentUser['role']) ?></strong>
                                </li>
                                <li><a class="dropdown-item py-2" href="<?= route_to('cart') ?>"><i class="bi bi-bag me-2"></i>Keranjang Saya</a></li>
                                <li><a class="dropdown-item py-2 text-danger" href="<?= route_to('logout') ?>"><i class="bi bi-box-arrow-right me-2"></i>Keluar</a></li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <a href="<?= route_to('login') ?>" class="btn btn-outline-primary rounded-3 fw-semibold px-3">Masuk</a>
                        <a href="<?= route_to('register') ?>" class="btn btn-se-coral px-3">Daftar</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>
</header>
