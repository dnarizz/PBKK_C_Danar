<?php
use App\Libraries\StoreCatalog;

/** @var array<string, mixed> $product */
$showFilterAttr = $showFilterAttr ?? false;
$colClass       = $colClass ?? 'col-12 col-sm-6 col-lg-3';
?>
<div class="<?= esc($colClass) ?>" <?= $showFilterAttr ? 'data-product-cat="' . esc($product['category_slug']) . '"' : '' ?>>
    <article class="se-product-card">
        <a href="<?= route_to('product.detail', $product['slug']) ?>" class="se-product-thumb d-block text-decoration-none">
            <img src="<?= base_url('assets/images/products/' . esc($product['image'])) ?>"
                 alt="<?= esc($product['name']) ?>"
                 loading="lazy">
            <?php if (! empty($product['badge'])): ?>
                <span class="se-product-badge"><?= esc($product['badge']) ?></span>
            <?php endif; ?>
        </a>

        <div class="p-3 d-flex flex-column flex-grow-1">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <a href="<?= route_to('category.show', $product['category_slug']) ?>" class="text-decoration-none small fw-semibold text-primary">
                    <?= esc($product['category_name']) ?>
                </a>
                <span class="se-stock-pill">Stok: <?= (int) $product['stock'] ?></span>
            </div>

            <h3 class="h6 fw-bold mb-1">
                <a href="<?= route_to('product.detail', $product['slug']) ?>" class="text-decoration-none text-dark">
                    <?= esc($product['name']) ?>
                </a>
            </h3>

            <p class="small text-muted mb-3 flex-grow-1"><?= esc($product['short_desc']) ?></p>

            <div class="d-flex align-items-center gap-2 small text-muted mb-2">
                <span class="text-warning"><i class="bi bi-star-fill"></i> <?= esc((string) $product['rating']) ?></span>
                <span>&bull;</span>
                <span><?= (int) $product['sold_count'] ?> terjual</span>
            </div>

            <div class="mb-3">
                <div class="se-price-current"><?= esc(StoreCatalog::formatRupiah($product['price'])) ?></div>
                <?php if (! empty($product['original_price'])): ?>
                    <div class="se-price-old"><?= esc(StoreCatalog::formatRupiah($product['original_price'])) ?></div>
                <?php endif; ?>
            </div>

            <div class="d-flex gap-2 mt-auto">
                <a href="<?= route_to('product.detail', $product['slug']) ?>" class="btn btn-outline-primary btn-sm flex-grow-1 fw-semibold rounded-3">
                    Detail
                </a>
                <form action="<?= route_to('cart.add') ?>" method="post">
                    <?= csrf_field() ?>
                    <input type="hidden" name="product_id" value="<?= (int) $product['id'] ?>">
                    <input type="hidden" name="quantity" value="1">
                    <button type="submit" class="btn btn-se-primary btn-sm px-3" title="Tambah ke Keranjang" aria-label="Tambah <?= esc($product['name']) ?> ke keranjang">
                        <i class="bi bi-cart-plus"></i>
                    </button>
                </form>
            </div>
        </div>
    </article>
</div>
