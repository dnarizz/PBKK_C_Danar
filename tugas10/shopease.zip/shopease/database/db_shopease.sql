-- =====================================================================
-- ShopEase - Online Store Database Schema & Seed Data
-- Referensi: PRD Bab 11 (Rancangan Database) & HOL Praktikum 2
-- =====================================================================

CREATE DATABASE IF NOT EXISTS db_shopease
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE db_shopease;

-- 1. Tabel users (Customer, Administrator, Operator)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('customer', 'admin', 'operator') NOT NULL DEFAULT 'customer',
    phone VARCHAR(25) NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_users_role (role)
) ENGINE=InnoDB;

-- 2. Tabel categories
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(120) NOT NULL UNIQUE,
    description TEXT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 3. Tabel products
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    name VARCHAR(150) NOT NULL,
    slug VARCHAR(170) NOT NULL UNIQUE,
    description TEXT NULL,
    price DECIMAL(12, 2) NOT NULL,
    stock INT NOT NULL DEFAULT 0,
    image VARCHAR(255) NULL,
    status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_products_category (category_id),
    INDEX idx_products_status (status),
    INDEX idx_products_name (name),
    CONSTRAINT fk_products_category
        FOREIGN KEY (category_id) REFERENCES categories(id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
) ENGINE=InnoDB;

-- 4. Tabel carts
CREATE TABLE IF NOT EXISTS carts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_carts_user (user_id),
    CONSTRAINT fk_carts_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- 5. Tabel cart_items
CREATE TABLE IF NOT EXISTS cart_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cart_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_cart_product (cart_id, product_id),
    CONSTRAINT fk_cart_items_cart
        FOREIGN KEY (cart_id) REFERENCES carts(id)
        ON DELETE CASCADE,
    CONSTRAINT fk_cart_items_product
        FOREIGN KEY (product_id) REFERENCES products(id)
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- 6. Tabel addresses
CREATE TABLE IF NOT EXISTS addresses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    recipient_name VARCHAR(100) NOT NULL,
    phone VARCHAR(25) NOT NULL,
    address TEXT NOT NULL,
    city VARCHAR(100) NOT NULL,
    province VARCHAR(100) NOT NULL,
    postal_code VARCHAR(15) NOT NULL,
    is_default TINYINT(1) NOT NULL DEFAULT 0,
    INDEX idx_addresses_user (user_id),
    CONSTRAINT fk_addresses_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- 7. Tabel orders
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    address_id INT NULL,
    order_number VARCHAR(50) NOT NULL UNIQUE,
    order_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    subtotal DECIMAL(12, 2) NOT NULL,
    shipping_cost DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    total DECIMAL(12, 2) NOT NULL,
    order_status ENUM(
        'pending_payment',
        'waiting_verification',
        'processing',
        'shipped',
        'completed',
        'cancelled'
    ) NOT NULL DEFAULT 'pending_payment',
    notes TEXT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_orders_user (user_id),
    INDEX idx_orders_status (order_status),
    CONSTRAINT fk_orders_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_orders_address
        FOREIGN KEY (address_id) REFERENCES addresses(id)
        ON DELETE SET NULL
) ENGINE=InnoDB;

-- 8. Tabel order_items (snapshot nama & harga saat transaksi - BR-004)
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    product_name VARCHAR(150) NOT NULL,
    price DECIMAL(12, 2) NOT NULL,
    quantity INT NOT NULL,
    subtotal DECIMAL(12, 2) NOT NULL,
    INDEX idx_order_items_order (order_id),
    CONSTRAINT fk_order_items_order
        FOREIGN KEY (order_id) REFERENCES orders(id)
        ON DELETE CASCADE,
    CONSTRAINT fk_order_items_product
        FOREIGN KEY (product_id) REFERENCES products(id)
        ON DELETE RESTRICT
) ENGINE=InnoDB;

-- 9. Tabel payments (BR-008: atribut terpisah dari order_status)
CREATE TABLE IF NOT EXISTS payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    method VARCHAR(50) NOT NULL DEFAULT 'Transfer Bank Manual',
    amount DECIMAL(12, 2) NOT NULL,
    proof_file VARCHAR(255) NULL,
    payment_status ENUM('unpaid', 'submitted', 'verified', 'rejected') NOT NULL DEFAULT 'unpaid',
    verified_by INT NULL,
    verified_at DATETIME NULL,
    INDEX idx_payments_order (order_id),
    CONSTRAINT fk_payments_order
        FOREIGN KEY (order_id) REFERENCES orders(id)
        ON DELETE CASCADE,
    CONSTRAINT fk_payments_verifier
        FOREIGN KEY (verified_by) REFERENCES users(id)
        ON DELETE SET NULL
) ENGINE=InnoDB;

-- 10. Tabel shipments
CREATE TABLE IF NOT EXISTS shipments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    courier VARCHAR(100) NULL,
    tracking_number VARCHAR(100) NULL,
    shipment_status ENUM('pending', 'packed', 'shipped', 'delivered') NOT NULL DEFAULT 'pending',
    shipped_at DATETIME NULL,
    delivered_at DATETIME NULL,
    INDEX idx_shipments_order (order_id),
    CONSTRAINT fk_shipments_order
        FOREIGN KEY (order_id) REFERENCES orders(id)
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- Seed Data Contoh (Non-Pribadi / Demonstrasi)
-- =====================================================================

-- Password demo semua akun di bawah: shopease123 (bcrypt hash)
INSERT INTO users (name, email, password_hash, role, phone, is_active) VALUES
('Admin ShopEase Demo', 'admin@shopease-demo.local', '$2y$10$PAC7JBBnwyvIIiqmJu53Uu3vGYiJQpA9vcs5x30df9cwP0BGGU0Iu', 'admin', '081100001111', 1),
('Operator Gudang Demo', 'operator@shopease-demo.local', '$2y$10$PAC7JBBnwyvIIiqmJu53Uu3vGYiJQpA9vcs5x30df9cwP0BGGU0Iu', 'operator', '081100002222', 1),
('Pelanggan Contoh Satu', 'customer@shopease-demo.local', '$2y$10$PAC7JBBnwyvIIiqmJu53Uu3vGYiJQpA9vcs5x30df9cwP0BGGU0Iu', 'customer', '081100003333', 1),
('Pelanggan Contoh Dua', 'pelanggan2@shopease-demo.local', '$2y$10$PAC7JBBnwyvIIiqmJu53Uu3vGYiJQpA9vcs5x30df9cwP0BGGU0Iu', 'customer', '081100004444', 1);

INSERT INTO categories (id, name, slug, description, is_active) VALUES
(1, 'Elektronik', 'elektronik', 'Perangkat audio, komputasi, dan gadget harian bergaransi resmi.', 1),
(2, 'Fashion', 'fashion', 'Busana kasual, alas kaki, dan outerwear modern untuk aktivitas harian.', 1),
(3, 'Aksesoris', 'aksesoris', 'Ransel, pelindung perangkat, dan perlengkapan produktivitas.', 1),
(4, 'Rumah Tangga', 'rumah-tangga', 'Peralatan meja kerja, wadah minuman, dan kebutuhan ruang nyaman.', 1),
(5, 'Olahraga & Hobi', 'olahraga', 'Perlengkapan kebugaran, hidrasi, dan aktivitas luar ruang.', 1),
(6, 'Perawatan & Kecantikan', 'kecantikan', 'Produk perawatan kulit harian dengan formula ringan dan teruji.', 1);

INSERT INTO products (category_id, name, slug, description, price, stock, image, status) VALUES
(1, 'Wireless Headphone ANC Pro', 'wireless-headphone-pro', 'Headphone Bluetooth 5.3 dengan Active Noise Cancelling adaptif dan baterai hingga 38 jam.', 299000.00, 20, 'wireless-headphone.jpg', 'active'),
(2, 'Sneakers Casual Urban', 'sneakers-casual-urban', 'Sepatu kasual sol empuk berbahan mesh breathable untuk mobilitas kampus dan kerja.', 350000.00, 15, 'sneakers-casual.svg', 'active'),
(1, 'Smart Watch Fit Series', 'smart-watch-fit-series', 'Jam tangan pintar layar AMOLED dengan pemantauan detak jantung, SpO2, dan tahan air 5ATM.', 450000.00, 12, 'smart-watch.svg', 'active'),
(1, 'Keyboard Mekanikal Wireless 75%', 'keyboard-mekanikal-75', 'Keyboard mekanikal compact 84 tombol hot-swappable dengan koneksi tri-mode USB-C, 2.4GHz, dan Bluetooth.', 649000.00, 18, 'mechanical-keyboard.svg', 'active'),
(3, 'Ransel Laptop Anti Air 15.6"', 'ransel-laptop-anti-air', 'Tas punggung kompartemen laptop empuk 15.6 inci, bahan water-repellent, serta slot pengisian USB eksternal.', 275000.00, 25, 'laptop-backpack.svg', 'active'),
(4, 'Tumbler Vacuum Stainless 500ml', 'tumbler-vacuum-500ml', 'Botol minum dinding ganda stainless 304 tahan panas hingga 12 jam dan dingin 24 jam.', 129000.00, 40, 'coffee-tumbler.svg', 'active'),
(4, 'Lampu Meja LED Minimalis Touch', 'lampu-meja-led-touch', 'Lampu belajar dan kerja dengan 3 mode suhu warna, peredup sentuh, dan leher fleksibel anti-silau.', 185000.00, 22, 'desk-lamp.svg', 'active'),
(6, 'Hydra Glow Facial Serum 30ml', 'hydra-glow-serum-30ml', 'Serum wajah hidrasi intensif dengan Niacinamide 5% dan Hyaluronic Acid untuk kulit terasa segar.', 149000.00, 30, 'skincare-serum.jpg', 'active'),
(5, 'Botol Minum Sport Tritan 1L', 'botol-minum-sport-1l', 'Botol olahraga bebas BPA kapasitas 1 liter dengan penanda takaran waktu dan tutup flip-top.', 95000.00, 35, 'running-bottle.svg', 'active'),
(2, 'Jaket Overshirt Denim Casual', 'jaket-overshirt-denim', 'Luaran denim katun twill 12 oz potongan santai dengan dua saku dada fungsional.', 389000.00, 14, 'denim-jacket.svg', 'active'),
(1, 'Adapter Charger Lama (Arsip Nonaktif)', 'produk-nonaktif-demo', 'Produk contoh berstatus nonaktif untuk menguji aturan bisnis BR-002.', 89000.00, 0, 'wireless-headphone.jpg', 'inactive');
