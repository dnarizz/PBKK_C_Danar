/**
 * ShopEase Frontend Interactions
 * - Filter instan tab kategori di Landing Page
 * - Stepper kuantitas pada halaman detail produk
 */
document.addEventListener('DOMContentLoaded', () => {
    // 1. Filter instan produk unggulan pada Landing Page
    const filterButtons = document.querySelectorAll('[data-filter-cat]');
    const productItems = document.querySelectorAll('[data-product-cat]');

    if (filterButtons.length > 0 && productItems.length > 0) {
        filterButtons.forEach((btn) => {
            btn.addEventListener('click', () => {
                const target = btn.getAttribute('data-filter-cat') || 'all';

                filterButtons.forEach((b) => b.classList.remove('active'));
                btn.classList.add('active');

                productItems.forEach((item) => {
                    const cat = item.getAttribute('data-product-cat');
                    if (target === 'all' || cat === target) {
                        item.classList.remove('d-none');
                    } else {
                        item.classList.add('d-none');
                    }
                });
            });
        });
    }

    // 2. Stepper kuantitas (+ / -) di halaman detail produk
    document.querySelectorAll('[data-qty-stepper]').forEach((wrapper) => {
        const input = wrapper.querySelector('input[type="number"]');
        const minusBtn = wrapper.querySelector('[data-qty-minus]');
        const plusBtn = wrapper.querySelector('[data-qty-plus]');

        if (!input) {
            return;
        }

        const min = parseInt(input.getAttribute('min') || '1', 10);
        const max = parseInt(input.getAttribute('max') || '99', 10);

        if (minusBtn) {
            minusBtn.addEventListener('click', () => {
                const current = parseInt(input.value || String(min), 10);
                input.value = String(Math.max(min, current - 1));
            });
        }

        if (plusBtn) {
            plusBtn.addEventListener('click', () => {
                const current = parseInt(input.value || String(min), 10);
                input.value = String(Math.min(max, current + 1));
            });
        }
    });
});
